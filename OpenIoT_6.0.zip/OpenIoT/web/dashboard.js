/*****************************************************************
    OpenIoT Framework
    Dashboard JavaScript
*****************************************************************/

const REFRESH_INTERVAL = 2000;

//----------------------------------------------------------
// Helpers
//----------------------------------------------------------

function $(id)
{
    return document.getElementById(id);
}

function setText(id, value)
{
    const el = $(id);

    if (el)
        el.textContent = value;
}

function setStatus(id, ok, text)
{
    const el = $(id);

    if (!el)
        return;

    el.textContent = text;

    if (ok)
    {
        el.className = "status online";
    }
    else
    {
        el.className = "status offline";
    }
}

function formatUptime(ms)
{
    let sec = Math.floor(ms / 1000);

    let days = Math.floor(sec / 86400);
    sec %= 86400;

    let hrs = Math.floor(sec / 3600);
    sec %= 3600;

    let mins = Math.floor(sec / 60);
    sec %= 60;

    return (
        days + "d " +
        hrs + "h " +
        mins + "m " +
        sec + "s"
    );
}


//----------------------------------------------------------
// Fetch JSON
//----------------------------------------------------------

async function loadJSON(url)
{
    const response = await fetch(url);

    if (!response.ok)
        throw new Error(response.status);

    return await response.json();
}


//----------------------------------------------------------
// System
//----------------------------------------------------------

async function updateSystem()
{
    try
    {
        const data =
            await loadJSON("/api/v1/system");

        setText("framework", data.framework);
        setText("version", data.version);
        setText("chip", data.chip);
        setText("uptime", formatUptime(data.uptime));

        if (data.cpu)
            setText("cpu", data.cpu + " MHz");

        if (data.flash)
            setText("flash", data.flash + " KB");

        if (data.heap)
            setText("heap", data.heap + " KB");

        if (data.freeheap)
            setText("freeheap", data.freeheap + " KB");
    }
    catch(e)
    {
        console.log(e);
    }
}


//----------------------------------------------------------
// Network
//----------------------------------------------------------

async function updateNetwork()
{
    try
    {
        const data =
            await loadJSON("/api/v1/network");

        setStatus(
            "wifiStatus",
            data.connected,
            data.connected ? "Connected" : "Offline"
        );

        setText("ip", data.ip);
        setText("rssi", data.rssi + " dBm");
    }
    catch(e)
    {
        console.log(e);
    }
}


//----------------------------------------------------------
// Device
//----------------------------------------------------------

async function updateDevice()
{
    try
    {
        const data =
            await loadJSON("/api/v1/device");

        setText("device", data.name);
        setText("firmware", data.firmware);
    }
    catch(e)
    {
        console.log(e);
    }
}


//----------------------------------------------------------
// MQTT
//----------------------------------------------------------

async function updateMQTT()
{
    try
    {
        const data =
            await loadJSON("/api/v1/mqtt");

        setStatus(
            "mqttStatus",
            data.connected,
            data.connected ?
            "Connected" :
            "Disconnected"
        );

        setText("broker", data.host);
        setText("clientid", data.clientid);
    }
    catch(e)
    {
    }
}


//----------------------------------------------------------
// OTA
//----------------------------------------------------------

async function updateOTA()
{
    try
    {
        const data =
            await loadJSON("/api/v1/ota");

        setStatus(
            "otaStatus",
            data.enabled,
            data.enabled ?
            "Enabled" :
            "Disabled"
        );

        setText(
            "hostname",
            data.hostname
        );
    }
    catch(e)
    {
    }
}


//----------------------------------------------------------
// Memory
//----------------------------------------------------------

async function updateMemory()
{
    try
    {
        const data =
            await loadJSON("/api/v1/system");

        if(data.heap)
            setText(
                "heapUsed",
                data.heap + " KB"
            );

        if(data.freeheap)
            setText(
                "heapFree",
                data.freeheap + " KB"
            );
    }
    catch(e)
    {
    }
}


//----------------------------------------------------------
// Refresh Everything
//----------------------------------------------------------

async function refreshDashboard()
{
    updateSystem();
    updateDevice();
    updateNetwork();
    updateMQTT();
    updateOTA();
    updateMemory();
}


//----------------------------------------------------------
// Start
//----------------------------------------------------------

window.onload = function()
{
    refreshDashboard();

    setInterval(
        refreshDashboard,
        REFRESH_INTERVAL
    );
};







setInterval(async () => {

    const res = await fetch("/api/v1/status");
    const data = await res.json();

    updateSystem(data.system);
    updateNetwork(data.network);
    updateMQTT(data.mqtt);
    updateOTA(data.ota);
    updateStorage(data.storage);
    updateDevice(data.device);

},1000);