/*****************************************************************
    OpenIoT Framework

    File        : ServiceManager.cpp
    Description : Framework Service Registry

    Version     : 2.1.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "ServiceManager.h"
#include "LoggerManager.h"

#include <string.h>

namespace OIF
{

//==============================================================
// Service Constructor
//==============================================================

Service::Service(
    ServiceId id,
    const char* name
)
    : _id(id),
      _name(name),
      _enabled(true)
{
}


//==============================================================
// Service Registry Constructor
//==============================================================

ServiceRegistry::ServiceRegistry()
    : _count(0)
{
    clear();
}


//==============================================================
// Clear Registry
//==============================================================

void ServiceRegistry::clear()
{
    for (uint8_t i = 0; i < MAX_SERVICES; i++)
    {
        _services[i] = nullptr;
    }

    _count = 0;
}


//==============================================================
// Add Service
//==============================================================

Result ServiceRegistry::add(
    Service* service
)
{
    if (service == nullptr)
    {
        return Result::INVALID_PARAMETER;
    }

    if (full())
    {
        return Result::BUSY;
    }

    //----------------------------------------------------------
    // Prevent duplicates
    //----------------------------------------------------------

    for (uint8_t i = 0; i < _count; i++)
    {
        if (_services[i] == service)
        {
            return Result::ALREADY_EXISTS;
        }

        if (_services[i]->id() == service->id())
        {
            return Result::ALREADY_EXISTS;
        }
    }

    _services[_count++] = service;

    Log.info(
        "SERVICE",
        "Registered : %s",
        service->name()
    );

    return Result::OK;
}


//==============================================================
// Remove Service
//==============================================================

Result ServiceRegistry::remove(
    Service* service
)
{
    if (service == nullptr)
    {
        return Result::INVALID_PARAMETER;
    }

    for (uint8_t i = 0; i < _count; i++)
    {
        if (_services[i] != service)
            continue;

        Log.info(
            "SERVICE",
            "Removed : %s",
            service->name()
        );

        for (uint8_t j = i; j < (_count - 1); j++)
        {
            _services[j] = _services[j + 1];
        }

        _services[--_count] = nullptr;

        return Result::OK;
    }

    return Result::NOT_FOUND;
}


//==============================================================
// Find Service by ID
//==============================================================

Service* ServiceRegistry::find(
    ServiceId id
) const
{
    for (uint8_t i = 0; i < _count; i++)
    {
        if (_services[i] == nullptr)
            continue;

        if (_services[i]->id() == id)
        {
            return _services[i];
        }
    }

    return nullptr;
}


//==============================================================
// Find Service by Name
//==============================================================

Service* ServiceRegistry::find(
    const char* name
) const
{
    if (name == nullptr)
        return nullptr;

    for (uint8_t i = 0; i < _count; i++)
    {
        if (_services[i] == nullptr)
            continue;

        if (strcmp(
                _services[i]->name(),
                name
            ) == 0)
        {
            return _services[i];
        }
    }

    return nullptr;
}


//==============================================================
// Get Service by Index
//==============================================================

Service* ServiceRegistry::get(
    uint8_t index
) const
{
    if (index >= _count)
    {
        return nullptr;
    }

    return _services[index];
}


//==============================================================
// Service Exists
//==============================================================

bool ServiceRegistry::exists(
    ServiceId id
) const
{
    return (find(id) != nullptr);
}


//==============================================================
// Begin All Services
//==============================================================

Result ServiceRegistry::beginAll()
{
    for (uint8_t i = 0; i < _count; i++)
    {
        Service* service = _services[i];

        if (service == nullptr)
            continue;

        if (!service->enabled())
            continue;

        Result result = service->begin();

        if (result != Result::OK)
        {
            Log.warning(
                "SERVICE",
                "Begin failed : %s",
                service->name()
            );
        }
    }

    return Result::OK;
}


//==============================================================
// Run All Services
//==============================================================

Result ServiceRegistry::runAll()
{
    for (uint8_t i = 0; i < _count; i++)
    {
        Service* service = _services[i];

        if (service == nullptr)
            continue;

        if (!service->enabled())
            continue;

        service->run();
    }

    return Result::OK;
}


//==============================================================
// Stop All Services
//==============================================================

Result ServiceRegistry::stopAll()
{
    for (int i = _count - 1; i >= 0; i--)
    {
        Service* service = _services[i];

        if (service == nullptr)
            continue;

        if (!service->enabled())
            continue;

        service->stop();
    }

    return Result::OK;
}


//==============================================================
// Enable All Services
//==============================================================

void ServiceRegistry::enableAll()
{
    for (uint8_t i = 0; i < _count; i++)
    {
        if (_services[i] != nullptr)
        {
            _services[i]->enable();
        }
    }
}


//==============================================================
// Disable All Services
//==============================================================

void ServiceRegistry::disableAll()
{
    for (uint8_t i = 0; i < _count; i++)
    {
        if (_services[i] != nullptr)
        {
            _services[i]->disable();
        }
    }
}


//==============================================================
// Registry Information
//==============================================================

uint8_t ServiceRegistry::count() const
{
    return _count;
}


bool ServiceRegistry::empty() const
{
    return (_count == 0);
}


bool ServiceRegistry::full() const
{
    return (_count >= MAX_SERVICES);
}


uint8_t ServiceRegistry::capacity() const
{
    return MAX_SERVICES;
}

} // namespace OIF