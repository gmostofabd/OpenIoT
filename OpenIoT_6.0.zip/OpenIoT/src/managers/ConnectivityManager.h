#pragma once

#ifndef OIF_CONNECTIVITY_MANAGER_H
#define OIF_CONNECTIVITY_MANAGER_H

/*****************************************************************
    OpenIoT Framework

    File        : ConnectivityManager.h
    Description : WiFi Connectivity Manager

    Version     : 2.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "../Platform.h"

namespace OIF
{

//==============================================================
// WiFi Connectivity Manager
//==============================================================

class ConnectivityManager
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    ConnectivityManager();

    //----------------------------------------------------------
    // Framework Lifecycle
    //----------------------------------------------------------

    bool begin();

    void run();

    void stop();

    //----------------------------------------------------------
    // WiFi Control
    //----------------------------------------------------------

    bool connect();

    void disconnect();

    bool reconnect();

    //----------------------------------------------------------
    // Connection Status
    //----------------------------------------------------------

    bool connected() const;

    bool isConnected() const;

    bool isConnecting() const;

    //----------------------------------------------------------
    // Network Information
    //----------------------------------------------------------

    String ipAddress() const;

    String macAddress() const;

    String ssid() const;

    String hostname() const;

    String gateway() const;

    String subnetMask() const;

    String dnsServer() const;

    int signalStrength() const;

    //----------------------------------------------------------
    // Optional Helpers
    //----------------------------------------------------------

    int signalQuality() const;

    //----------------------------------------------------------
    // Statistics
    //----------------------------------------------------------

    unsigned long reconnectTime() const;

    unsigned long uptime() const;

private:

    //----------------------------------------------------------
    // Internal State
    //----------------------------------------------------------

    bool _connecting;

    unsigned long _lastReconnect;

    unsigned long _connectedTime;
};


//==============================================================
// Global Instance
//==============================================================

extern ConnectivityManager Connectivity;

} // namespace OIF

#endif // OIF_CONNECTIVITY_MANAGER_H