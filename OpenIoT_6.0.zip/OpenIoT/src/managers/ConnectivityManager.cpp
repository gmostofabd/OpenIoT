/*****************************************************************
    OpenIoT Framework

    File        : ConnectivityManager.cpp
    Description : WiFi Connectivity Manager

    Version     : 2.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "ConnectivityManager.h"

#include "ConfigManager.h"
#include "LoggerManager.h"

namespace OIF
{

//==============================================================
// Global Instance
//==============================================================

ConnectivityManager Connectivity;


//==============================================================
// Constructor
//==============================================================

ConnectivityManager::ConnectivityManager()
    : _connecting(false),
      _lastReconnect(0),
      _connectedTime(0)
{
}


//==============================================================
// Initialize
//==============================================================

bool ConnectivityManager::begin()
{
    Log.info(
        "NET",
        "Initializing WiFi"
    );

#if defined(ESP32)

    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(true);

#elif defined(ESP8266)

    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(true);
    WiFi.persistent(true);

#endif

    connect();

    return true;
}


//==============================================================
// Main Task
//==============================================================

void ConnectivityManager::run()
{
    //----------------------------------------------------------
    // Waiting for connection
    //----------------------------------------------------------

    if (_connecting)
    {
        if (WiFi.status() == WL_CONNECTED)
        {
            _connecting = false;
            _connectedTime = millis();

            Log.success(
                "NET",
                "Connected"
            );

            Log.info(
                "NET",
                "IP : %s",
                WiFi.localIP().toString().c_str()
            );
        }

        return;
    }

    //----------------------------------------------------------
    // Connection Lost
    //----------------------------------------------------------

    if (!connected())
    {
        if (millis() - _lastReconnect >= 10000)
        {
            reconnect();
        }
    }
}


//==============================================================
// Connect
//==============================================================

bool ConnectivityManager::connect()
{
    const NetworkConfig& cfg =
        Config.network();

    _lastReconnect = millis();

    Log.info(
        "NET",
        "Connecting to %s",
        cfg.ssid
    );

#if defined(ESP32)

    WiFi.setHostname(cfg.hostname);

#elif defined(ESP8266)

    WiFi.hostname(cfg.hostname);

#endif

    WiFi.begin(
        cfg.ssid,
        cfg.password
    );

    _connecting = true;

    return true;
}


//==============================================================
// Disconnect
//==============================================================

void ConnectivityManager::disconnect()
{
    _connecting = false;

    WiFi.disconnect(true);

    Log.info(
        "NET",
        "Disconnected"
    );
}


//==============================================================
// Stop
//==============================================================

void ConnectivityManager::stop()
{
    disconnect();
}


//==============================================================
// Reconnect
//==============================================================

bool ConnectivityManager::reconnect()
{
    Log.warning(
        "NET",
        "Reconnecting..."
    );

    disconnect();

    delay(100);

    return connect();
}


//==============================================================
// Status
//==============================================================

bool ConnectivityManager::connected() const
{
    return WiFi.status() == WL_CONNECTED;
}


bool ConnectivityManager::isConnected() const
{
    return connected();
}


bool ConnectivityManager::isConnecting() const
{
    return _connecting;
}


//==============================================================
// Network Information
//==============================================================

String ConnectivityManager::ipAddress() const
{
    if (!connected())
        return "0.0.0.0";

    return WiFi.localIP().toString();
}


String ConnectivityManager::gateway() const
{
    if (!connected())
        return "";

    return WiFi.gatewayIP().toString();
}


String ConnectivityManager::subnetMask() const
{
    if (!connected())
        return "";

    return WiFi.subnetMask().toString();
}


String ConnectivityManager::dnsServer() const
{
    if (!connected())
        return "";

    return WiFi.dnsIP().toString();
}


String ConnectivityManager::hostname() const
{
#if defined(ESP32)

    return WiFi.getHostname();

#elif defined(ESP8266)

    return WiFi.hostname();

#endif
}


String ConnectivityManager::macAddress() const
{
    return WiFi.macAddress();
}


String ConnectivityManager::ssid() const
{
    if (!connected())
        return "";

    return WiFi.SSID();
}


int ConnectivityManager::signalStrength() const
{
    if (!connected())
        return 0;

    return WiFi.RSSI();
}


//==============================================================
// Statistics
//==============================================================

unsigned long ConnectivityManager::reconnectTime() const
{
    return _lastReconnect;
}


unsigned long ConnectivityManager::uptime() const
{
    if (!connected())
        return 0;

    return millis() - _connectedTime;
}

} // namespace OIF