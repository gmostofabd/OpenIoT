/*****************************************************************
    OpenIoT Framework

    File        : DashboardManager.cpp
    Description : Dashboard Manager

    Version     : 2.0.0

    License     : MIT
*****************************************************************/

#include "DashboardManager.h"

#include "LoggerManager.h"
#include "VersionManager.h"

namespace OIF
{

DashboardManager Dashboard;

/*********************************************************
    Constructor
*********************************************************/

DashboardManager::DashboardManager()
{
}


/*********************************************************
    Initialize
*********************************************************/

bool DashboardManager::begin()
{
    Log.info(
        "DASH",
        "Dashboard Initialized"
    );

    return true;
}


/*********************************************************
    Main Task
*********************************************************/

void DashboardManager::run()
{
    // Reserved for future dashboard tasks
}


/*********************************************************
    Shutdown
*********************************************************/

void DashboardManager::stop()
{
    Log.info(
        "DASH",
        "Dashboard Stopped"
    );
}


String DashboardManager::html() const
{
    return R"rawliteral(
<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>OpenIoT Dashboard</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,Helvetica,sans-serif;
}

body{
background:#0f172a;
color:#fff;
padding:20px;
}

h1{
font-size:30px;
margin-bottom:20px;
}

.grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
gap:18px;
}

.card{
background:#1e293b;
padding:20px;
border-radius:12px;
box-shadow:0 4px 12px rgba(0,0,0,.25);
}

.card h3{
font-size:15px;
color:#94a3b8;
margin-bottom:10px;
}

.value{
font-size:28px;
font-weight:bold;
}

.ok{
color:#22c55e;
}

.warn{
color:#f59e0b;
}

.bad{
color:#ef4444;
}

table{
width:100%;
margin-top:25px;
border-collapse:collapse;
}

td{
padding:10px;
border-bottom:1px solid #334155;
}

.footer{
margin-top:25px;
text-align:center;
color:#94a3b8;
font-size:14px;
}

</style>

</head>

<body>

<h1>OpenIoT Framework</h1>

<div class="grid">

<div class="card">
<h3>Framework</h3>
<div class="value" id="version">--</div>
</div>

<div class="card">
<h3>WiFi</h3>
<div class="value ok" id="wifi">--</div>
</div>

<div class="card">
<h3>RSSI</h3>
<div class="value" id="rssi">--</div>
</div>

<div class="card">
<h3>CPU</h3>
<div class="value" id="cpu">ESP32</div>
</div>

<div class="card">
<h3>RAM</h3>
<div class="value" id="ram">--</div>
</div>

<div class="card">
<h3>MQTT</h3>
<div class="value" id="mqtt">--</div>
</div>

<div class="card">
<h3>OTA</h3>
<div class="value" id="ota">Ready</div>
</div>

<div class="card">
<h3>Uptime</h3>
<div class="value" id="uptime">0</div>
</div>

</div>

<table>

<tr>
<td>Device</td>
<td id="device">-</td>
</tr>

<tr>
<td>Firmware</td>
<td id="firmware">-</td>
</tr>

<tr>
<td>IP Address</td>
<td id="ip">-</td>
</tr>

<tr>
<td>JSON API</td>
<td>/api/v1/system</td>
</tr>

</table>

<div class="footer">
OpenIoT Framework Live Dashboard
</div>

<script>

async function updateDashboard(){

try{

const system=await fetch('/api/v1/system').then(r=>r.json());
const device=await fetch('/api/v1/device').then(r=>r.json());
const network=await fetch('/api/v1/network').then(r=>r.json());

document.getElementById('version').innerHTML=system.version;
document.getElementById('cpu').innerHTML=system.chip;
document.getElementById('uptime').innerHTML=Math.floor(system.uptime/1000)+' s';

document.getElementById('device').innerHTML=device.name;
document.getElementById('firmware').innerHTML=device.firmware;

document.getElementById('wifi').innerHTML=network.connected?'Connected':'Offline';
document.getElementById('wifi').className='value '+(network.connected?'ok':'bad');

document.getElementById('ip').innerHTML=network.ip;
document.getElementById('rssi').innerHTML=network.rssi+' dBm';

document.getElementById('mqtt').innerHTML=network.mqtt?'Connected':'Disconnected';
document.getElementById('mqtt').className='value '+(network.mqtt?'ok':'warn');

document.getElementById('ram').innerHTML=(system.freeHeap/1024).toFixed(1)+' KB';

}catch(e){
console.log(e);
}

}

updateDashboard();

setInterval(updateDashboard,1000);

</script>

</body>
</html>
)rawliteral";
}

}