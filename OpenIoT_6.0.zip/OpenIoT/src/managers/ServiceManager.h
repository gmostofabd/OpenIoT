#pragma once
#ifndef OIF_SERVICE_MANAGER_H
#define OIF_SERVICE_MANAGER_H

/*****************************************************************
    OpenIoT Framework

    File        : ServiceManager.h
    Description : Framework Service Registry

    Version     : 2.1.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "../Platform.h"

namespace OIF
{

//==============================================================
// Result Codes
//==============================================================

enum class Result : uint8_t
{
    OK = 0,
    ERROR,
    INVALID_PARAMETER,
    NOT_FOUND,
    ALREADY_EXISTS,
    NOT_SUPPORTED,
    TIMEOUT,
    BUSY
};


//==============================================================
// Service IDs
//==============================================================

enum class ServiceId : uint8_t
{
    UNKNOWN = 0,

    //----------------------------------------------------------
    // Core
    //----------------------------------------------------------

    LOGGER,
    VERSION,
    CONFIG,
    FILESYSTEM,

    //----------------------------------------------------------
    // Network
    //----------------------------------------------------------

    CONNECTIVITY,
    WEB,
    DASHBOARD,
    JSON,

    //----------------------------------------------------------
    // OTA
    //----------------------------------------------------------

    OTA,
    GITHUB_OTA,

    //----------------------------------------------------------
    // Cloud
    //----------------------------------------------------------

    MQTT,
    FIREBASE,

    //----------------------------------------------------------
    // Hardware
    //----------------------------------------------------------

    SENSOR,

    //----------------------------------------------------------
    // User Extension
    //----------------------------------------------------------

    USER_SERVICE
};


//==============================================================
// Base Service
//==============================================================

class Service
{
public:

    Service(
        ServiceId id,
        const char* name
    );

    virtual ~Service() = default;

    //----------------------------------------------------------
    // Framework Lifecycle
    //----------------------------------------------------------

    virtual Result begin()
    {
        return Result::OK;
    }

    virtual Result run()
    {
        return Result::OK;
    }

    virtual Result stop()
    {
        return Result::OK;
    }

    //----------------------------------------------------------
    // Information
    //----------------------------------------------------------

    ServiceId id() const
    {
        return _id;
    }

    const char* name() const
    {
        return _name;
    }

    virtual const char* description() const
    {
        return "";
    }

    virtual uint16_t version() const
    {
        return 1;
    }

    //----------------------------------------------------------
    // Enable / Disable
    //----------------------------------------------------------

    void enable(bool state = true)
    {
        _enabled = state;
    }

    void disable()
    {
        _enabled = false;
    }

    bool enabled() const
    {
        return _enabled;
    }

protected:

    ServiceId _id;

    const char* _name;

    bool _enabled;
};


//==============================================================
// Service Registry
//==============================================================

class ServiceRegistry
{
public:

    static constexpr uint8_t MAX_SERVICES = 32;

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    ServiceRegistry();

    //----------------------------------------------------------
    // Registry Management
    //----------------------------------------------------------

    Result add(Service* service);

    Result remove(Service* service);

    void clear();

    //----------------------------------------------------------
    // Lookup
    //----------------------------------------------------------

    Service* find(ServiceId id) const;

    Service* find(const char* name) const;

    Service* get(uint8_t index) const;

    Service* operator[](uint8_t index) const
    {
        return get(index);
    }

    bool exists(ServiceId id) const;

    //----------------------------------------------------------
    // Framework Control
    //----------------------------------------------------------

    Result beginAll();

    Result runAll();

    Result stopAll();

    void enableAll();

    void disableAll();

    //----------------------------------------------------------
    // Information
    //----------------------------------------------------------

    uint8_t count() const;

    uint8_t size() const;

    uint8_t capacity() const;

    bool empty() const;

    bool full() const;

    //----------------------------------------------------------
    // Iterator
    //----------------------------------------------------------

    template<typename Function>
    void forEach(Function func)
    {
        for (uint8_t i = 0; i < _count; i++)
        {
            if (_services[i] != nullptr)
            {
                func(_services[i]);
            }
        }
    }

private:

    Service* _services[MAX_SERVICES];

    uint8_t _count;
};

} // namespace OIF

#endif // OIF_SERVICE_MANAGER_H