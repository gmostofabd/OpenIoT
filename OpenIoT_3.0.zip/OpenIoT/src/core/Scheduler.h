#pragma once

#include <Arduino.h>
#include "Service.h"

namespace OpenIoT
{

class Scheduler
{
public:

    static constexpr uint8_t MAX_SERVICES = 16;

    Scheduler()
        : _count(0)
    {
    }

    bool add(Service* service)
    {
        if (_count >= MAX_SERVICES)
            return false;

        _services[_count++] = service;
        return true;
    }

    Result begin()
    {
        for (uint8_t i = 0; i < _count; i++)
        {
            Result r = _services[i]->begin();

            if (!r)
                return r;
        }

        return Result::success();
    }

    void update()
    {
        for (uint8_t i = 0; i < _count; i++)
        {
            if (_services[i]->enabled())
                _services[i]->update();
        }
    }

    Result stop()
    {
        for (uint8_t i = 0; i < _count; i++)
            _services[i]->stop();

        return Result::success();
    }

private:

    Service* _services[MAX_SERVICES];
    uint8_t _count;
};

}