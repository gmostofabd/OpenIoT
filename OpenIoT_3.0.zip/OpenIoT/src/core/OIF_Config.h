#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : OIF_Config.h
    Description : Global Framework Configuration

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#ifndef OIF_CONFIG_H
#define OIF_CONFIG_H

#include <Arduino.h>

namespace OIF
{
namespace Config
{

//==============================================================
// Framework Information
//==============================================================

constexpr const char FRAMEWORK_NAME[]    = "OpenIoT";
constexpr const char FRAMEWORK_VERSION[] = "1.0.0";


//==============================================================
// Framework Limits
//==============================================================

constexpr uint8_t MAX_SERVICES = 16;
constexpr uint8_t MAX_DEVICES  = 32;
constexpr uint8_t MAX_DRIVERS  = 32;


//==============================================================
// Communication
//==============================================================

constexpr uint16_t MAX_PACKET_SIZE = 512;

constexpr uint16_t UART_RX_BUFFER  = 256;
constexpr uint16_t UART_TX_BUFFER  = 256;

constexpr uint16_t HTTP_PORT       = 80;
constexpr uint16_t HTTPS_PORT      = 443;


//==============================================================
// Logger
//==============================================================

constexpr uint16_t LOG_BUFFER_SIZE = 256;


//==============================================================
// Dashboard
//==============================================================

constexpr uint8_t MAX_CLIENTS      = 5;

constexpr uint16_t MAX_JSON_SIZE   = 2048;
constexpr uint16_t MAX_HTML_SIZE   = 32768;


//==============================================================
// OTA
//==============================================================

constexpr uint16_t OTA_PORT        = 3232;


//==============================================================
// Timing
//==============================================================

constexpr uint32_t DEFAULT_UPDATE_MS   = 10;

constexpr uint32_t WATCHDOG_TIMEOUT    = 5000;

constexpr uint32_t WIFI_CONNECT_TIMEOUT = 20000;

constexpr uint32_t DASHBOARD_UPDATE_MS = 250;

constexpr uint32_t JSON_UPDATE_MS      = 1000;

constexpr uint32_t OTA_UPDATE_MS       = 10;

constexpr uint32_t WEB_UPDATE_MS       = 5;

} // namespace Config

} // namespace OIF

#endif // OIF_CONFIG_H