#pragma once

#include <Arduino.h>

namespace OpenIoT
{

enum class ErrorCode : uint8_t
{
    None = 0,
    Unknown,
    InvalidParameter,
    NotInitialized,
    AlreadyInitialized,
    Timeout,
    NetworkError,
    FileError,
    MemoryError,
    NotSupported
};

class Result
{
public:
    constexpr Result(ErrorCode code = ErrorCode::None,
                     const char* message = "")
        : _code(code), _message(message)
    {
    }

    constexpr bool ok() const
    {
        return _code == ErrorCode::None;
    }

    constexpr operator bool() const
    {
        return ok();
    }

    constexpr ErrorCode code() const
    {
        return _code;
    }

    constexpr const char* message() const
    {
        return _message;
    }

    static constexpr Result success()
    {
        return Result();
    }

private:
    ErrorCode _code;
    const char* _message;
};

}