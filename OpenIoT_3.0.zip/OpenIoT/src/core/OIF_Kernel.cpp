/*****************************************************************
    OpenIoT Framework

    File        : OIF_Kernel.cpp
    Description : Framework Kernel

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "OIF_Kernel.h"

namespace OIF
{

//==============================================================
// Global Instance
//==============================================================

Kernel OIF;


//==============================================================
// Constructor
//==============================================================

Kernel::Kernel()
{
}


//==============================================================
// Begin Framework
//==============================================================

Result Kernel::begin()
{
    const uint8_t count = _registry.count();

    for (uint8_t i = 0; i < count; i++)
    {
        Service* service = _registry.get(i);

        if (service == nullptr)
            continue;

        if (!service->enabled())
            continue;

        Result result = service->begin();

        if (result != Result::OK)
            return result;
    }

    return Result::OK;
}


//==============================================================
// Run Framework
//==============================================================

Result Kernel::run()
{
    const uint8_t count = _registry.count();

    for (uint8_t i = 0; i < count; i++)
    {
        Service* service = _registry.get(i);

        if (service == nullptr)
            continue;

        if (!service->enabled())
            continue;

        Result result = service->run();

        if (result != Result::OK)
            return result;
    }

    return Result::OK;
}


//==============================================================
// Stop Framework
//==============================================================

Result Kernel::stop()
{
    const uint8_t count = _registry.count();

    for (uint8_t i = 0; i < count; i++)
    {
        Service* service = _registry.get(i);

        if (service == nullptr)
            continue;

        if (!service->enabled())
            continue;

        Result result = service->stop();

        if (result != Result::OK)
            return result;
    }

    return Result::OK;
}


//==============================================================
// Add Service
//==============================================================

Result Kernel::addService(
    Service* service
)
{
    if (service == nullptr)
        return Result::INVALID_PARAMETER;

    return _registry.add(service);
}


//==============================================================
// Remove Service
//==============================================================

Result Kernel::removeService(
    Service* service
)
{
    if (service == nullptr)
        return Result::INVALID_PARAMETER;

    return _registry.remove(service);
}


//==============================================================
// Find Service
//==============================================================

Service* Kernel::service(
    ServiceId id
)
{
    return _registry.find(id);
}


//==============================================================
// Service Count
//==============================================================

uint8_t Kernel::serviceCount() const
{
    return _registry.count();
}

} // namespace OIF