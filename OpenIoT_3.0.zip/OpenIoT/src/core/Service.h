#pragma once

#include "Result.h"

namespace OpenIoT
{

class Service
{
public:

    virtual ~Service() = default;

    virtual Result begin()
    {
        return Result::success();
    }

    virtual Result update()
    {
        return Result::success();
    }

    virtual Result stop()
    {
        return Result::success();
    }

    virtual const char* name() const = 0;

    virtual bool enabled() const
    {
        return true;
    }
};

}




class DashboardService : public Service
{
public:

    const char* name() const override
    {
        return "Dashboard";
    }

    Result begin() override;

    Result update() override;
};







