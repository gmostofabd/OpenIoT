#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : OpenIoT.h
    Description : Main Framework Interface

    Version     : 1.1.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "Platform.h"

//==============================================================
// Public Managers
//==============================================================

#include "managers/LoggerManager.h"
#include "managers/VersionManager.h"
#include "managers/ConnectivityManager.h"
#include "managers/DashboardManager.h"
#include "managers/WebManager.h"
#include "managers/OTAManager.h"

namespace OIF
{

//==============================================================
// Framework Constants
//==============================================================

constexpr const char* FRAMEWORK_NAME    = "OpenIoT";
constexpr const char* FRAMEWORK_VERSION = "1.1.0";


//==============================================================
// OpenIoT Framework
//==============================================================

class OpenIoT
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    OpenIoT();

    //----------------------------------------------------------
    // Framework Lifecycle
    //----------------------------------------------------------

    bool begin();

    void run();

    void stop();

    //----------------------------------------------------------
    // Status
    //----------------------------------------------------------

    bool initialized() const;

    //----------------------------------------------------------
    // Framework Information
    //----------------------------------------------------------

    const char* version() const;

    const char* name() const;

private:

    //----------------------------------------------------------
    // Internal State
    //----------------------------------------------------------

    bool _initialized = false;
};


//==============================================================
// Global Framework Instance
//==============================================================

extern OpenIoT Framework;

} // namespace OIF