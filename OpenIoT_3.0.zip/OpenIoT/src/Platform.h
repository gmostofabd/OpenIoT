#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : Platform.h
    Description : Platform Detection Layer

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#ifndef OIF_PLATFORM_H
#define OIF_PLATFORM_H

#include <Arduino.h>

//==============================================================
// Platform Detection
//==============================================================

#if defined(ESP32)

    #include <WiFi.h>
    #include <WebServer.h>
    #include <HTTPClient.h>
    #include <Update.h>
    #include <LittleFS.h>

    #define OIF_PLATFORM_NAME    "ESP32"
    #define OIF_PLATFORM_ESP32   1

#elif defined(ESP8266)

    #include <ESP8266WiFi.h>
    #include <ESP8266WebServer.h>
    #include <ESP8266HTTPClient.h>
    #include <ESP8266httpUpdate.h>
    #include <LittleFS.h>

    #define OIF_PLATFORM_NAME    "ESP8266"
    #define OIF_PLATFORM_ESP8266 1

#else

    #error OpenIoT Framework currently supports ESP32 and ESP8266 only.

#endif


//==============================================================
// Framework Information
//==============================================================

#define OIF_FRAMEWORK_NAME       "OpenIoT"
#define OIF_FRAMEWORK_VERSION    "1.0.0"


//==============================================================
// Common Filesystem Alias
//==============================================================

#define OIF_FS LittleFS


//==============================================================
// Common Constants
//==============================================================

#ifndef KB
    #define KB 1024UL
#endif

#ifndef MB
    #define MB (1024UL * 1024UL)
#endif


#endif // OIF_PLATFORM_H