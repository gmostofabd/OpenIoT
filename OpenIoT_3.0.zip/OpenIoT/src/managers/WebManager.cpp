/*****************************************************************
    OpenIoT Framework

    File        : WebManager.cpp
    Description : Embedded Web Server Manager

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "WebManager.h"

#include "DashboardManager.h"
#include "JSONManager.h"
#include "LoggerManager.h"
#include "VersionManager.h"

#if defined(ESP32)

#include <WiFi.h>

#elif defined(ESP8266)

#include <ESP8266WiFi.h>

#endif

namespace OIF
{

//==============================================================
// Global Instance
//==============================================================

WebManager Web;


//==============================================================
// Constructor
//==============================================================

WebManager::WebManager()

#if defined(ESP32)

    : _server(80)

#elif defined(ESP8266)

    : _server(80)

#endif

    , _running(false)
    , _waitingForWiFi(false)
    , _routesRegistered(false)
{
}

//==============================================================
// Initialize Web Server
//==============================================================

bool WebManager::begin()
{
    if (_running)
        return true;

    //----------------------------------------------------------
    // Wait for WiFi
    //----------------------------------------------------------

    if (WiFi.status() != WL_CONNECTED)
    {
        if (!_waitingForWiFi)
        {
            Log.info(
                "WEB",
                "Waiting for WiFi..."
            );

            _waitingForWiFi = true;
        }

        return true;
    }

    //----------------------------------------------------------
    // Register Routes (Only Once)
    //----------------------------------------------------------

    if (!_routesRegistered)
    {
        Log.info(
            "WEB",
            "Registering Routes"
        );

        registerRoutes();

        _routesRegistered = true;
    }

    //----------------------------------------------------------
    // Start Server
    //----------------------------------------------------------

    _server.begin();

    _running = true;
    _waitingForWiFi = false;

    String ip = WiFi.localIP().toString();

    Log.success(
        "WEB",
        "HTTP Server Started"
    );

    Log.info(
        "WEB",
        "IP Address : %s",
        ip.c_str()
    );

    return true;
}
//==============================================================
// Main Loop
//==============================================================

void WebManager::run()
{
    //----------------------------------------------------------
    // Not Running
    //----------------------------------------------------------

    if (!_running)
    {
        if (_waitingForWiFi &&
            WiFi.status() == WL_CONNECTED)
        {
            begin();
        }

        return;
    }

    //----------------------------------------------------------
    // WiFi Lost
    //----------------------------------------------------------

    if (WiFi.status() != WL_CONNECTED)
    {
        Log.warning(
            "WEB",
            "WiFi disconnected"
        );

        stop();

        _waitingForWiFi = true;

        return;
    }

    //----------------------------------------------------------
    // Handle HTTP Requests
    //----------------------------------------------------------

    _server.handleClient();
}

//==============================================================
// Stop Web Server
//==============================================================

void WebManager::stop()
{
    if (!_running)
        return;

    _server.stop();

    _running = false;

    Log.info(
        "WEB",
        "HTTP Server Stopped"
    );
}

//==============================================================
// Register Web Routes
//==============================================================

void WebManager::registerRoutes()
{
    //----------------------------------------------------------
    // Dashboard
    //----------------------------------------------------------

    _server.on(
        "/",
        HTTP_GET,
        [this]()
        {
            handleRoot();
        }
    );

    //----------------------------------------------------------
    // REST API
    //----------------------------------------------------------

    _server.on(
        "/api/v1/system",
        HTTP_GET,
        [this]()
        {
            handleSystem();
        }
    );

    _server.on(
        "/api/v1/device",
        HTTP_GET,
        [this]()
        {
            handleDevice();
        }
    );

    _server.on(
        "/api/v1/network",
        HTTP_GET,
        [this]()
        {
            handleNetwork();
        }
    );

    //----------------------------------------------------------
    // Health Check
    //----------------------------------------------------------

    _server.on(
        "/health",
        HTTP_GET,
        [this]()
        {
            handleHealth();
        }
    );

    //----------------------------------------------------------
    // Version
    //----------------------------------------------------------

    _server.on(
        "/version",
        HTTP_GET,
        [this]()
        {
            handleVersion();
        }
    );

    //----------------------------------------------------------
    // 404 Handler
    //----------------------------------------------------------

    _server.onNotFound(
        [this]()
        {
            handle404();
        }
    );
}


//==============================================================
// Send JSON Response
//==============================================================

void WebManager::sendJSON(
    const String& json,
    int code
)
{
    _server.sendHeader(
        "Access-Control-Allow-Origin",
        "*"
    );

    _server.sendHeader(
        "Cache-Control",
        "no-cache"
    );

    _server.sendHeader(
        "Connection",
        "close"
    );

    _server.send(
        code,
        "application/json",
        json
    );
}


//==============================================================
// Root Dashboard
//==============================================================

void WebManager::handleRoot()
{
    _server.sendHeader(
        "Cache-Control",
        "no-cache"
    );

    _server.send(
        200,
        "text/html",
        Dashboard.html()
    );
}


//==============================================================
// System JSON
//==============================================================

void WebManager::handleSystem()
{
    sendJSON(
        JSON.systemJSON()
    );
}


//==============================================================
// Device JSON
//==============================================================

void WebManager::handleDevice()
{
    sendJSON(
        JSON.deviceJSON()
    );
}


//==============================================================
// Network JSON
//==============================================================

void WebManager::handleNetwork()
{
    sendJSON(
        JSON.networkJSON()
    );
}


//==============================================================
// Health Endpoint
//==============================================================

void WebManager::handleHealth()
{
    String json;

    json.reserve(64);

    json =
        "{\"status\":\"OK\",\"uptime\":";

    json += millis();

    json += "}";

    sendJSON(json);
}


//==============================================================
// Version Endpoint
//==============================================================

void WebManager::handleVersion()
{
    String json;

    json.reserve(128);

    json =
        "{\"framework\":\"OpenIoT\",\"version\":\"";

    json += Version.version();

    json += "\"}";

    sendJSON(json);
}


//==============================================================
// 404 Handler
//==============================================================

void WebManager::handle404()
{
    sendJSON(
        "{\"error\":\"Not Found\"}",
        404
    );
}

} // namespace OIF