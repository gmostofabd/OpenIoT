/*****************************************************************
    OpenIoT Framework

    File        : GitHubOTA.cpp
    Description : GitHub OTA Engine

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "GitHubOTA.h"

#include "ConfigManager.h"
#include "VersionManager.h"
#include "LoggerManager.h"

#include <ArduinoJson.h>

#if defined(ESP32)

#include <WiFiClientSecure.h>

#endif

using namespace OIF;

//==============================================================
// Global Instance
//==============================================================

GitHubOTA GitHubUpdate;


//==============================================================
// Constructor
//==============================================================

GitHubOTA::GitHubOTA()
{
    memset(
        _remoteVersion,
        0,
        sizeof(_remoteVersion)
    );

    memset(
        _firmwareURL,
        0,
        sizeof(_firmwareURL)
    );
}


//==============================================================
// Initialize
//==============================================================

bool GitHubOTA::begin()
{
    Log.info(
        "GITHUB OTA",
        "OTA Engine Ready"
    );

    return true;
}


//==============================================================
// Check Remote Version
//==============================================================

bool GitHubOTA::checkVersion()
{
    String json;

    if (!downloadVersionFile(json))
    {
        Log.error(
            "GITHUB OTA",
            "Unable to download version file"
        );

        return false;
    }

    if (!parseVersion(json))
    {
        Log.error(
            "GITHUB OTA",
            "Invalid version file"
        );

        return false;
    }

    if (Version.isNewer(_remoteVersion))
    {
        Log.info(
            "GITHUB OTA",
            "New Firmware Available"
        );

        return true;
    }

    Log.info(
        "GITHUB OTA",
        "Already Latest Version"
    );

    return false;
}


//==============================================================
// Perform Update
//==============================================================

bool GitHubOTA::update()
{
    if (strlen(_firmwareURL) == 0)
    {
        Log.error(
            "GITHUB OTA",
            "Firmware URL Missing"
        );

        return false;
    }

    return downloadFirmware();
}


//==============================================================
// Remote Version
//==============================================================

const char* GitHubOTA::remoteVersion() const
{
    return _remoteVersion;
}


//==============================================================
// Download version.json
//==============================================================

bool GitHubOTA::downloadVersionFile(
    String& json
)
{
    const GitHubConfig& cfg =
        Config.github();

    String url =
        "https://raw.githubusercontent.com/";

    url += cfg.owner;
    url += "/";
    url += cfg.repository;
    url += "/";
    url += cfg.branch;
    url += "/version.json";

#if defined(ESP32)

    WiFiClientSecure client;
    client.setInsecure();

    HTTPClient http;

    http.begin(client, url);

#elif defined(ESP8266)

    WiFiClientSecure client;
    client.setInsecure();

    HTTPClient http;

    http.begin(client, url);

#endif

    http.setTimeout(15000);

    http.addHeader(
        "User-Agent",
        "OpenIoT"
    );

    int code = http.GET();

    if (code != HTTP_CODE_OK)
    {
        Log.printf(
            LogLevel::Error,
            "GITHUB OTA",
            "HTTP Error %d",
            code
        );

        http.end();

        return false;
    }

    json = http.getString();

    http.end();

    return true;
}


//==============================================================
// Parse Version JSON
//==============================================================

bool GitHubOTA::parseVersion(
    const String& json
)
{
    JsonDocument doc;

    if (deserializeJson(doc, json))
        return false;

    strncpy(
        _remoteVersion,
        doc["version"] | "0.0.0",
        sizeof(_remoteVersion) - 1
    );

    strncpy(
        _firmwareURL,
        doc["firmware"] | "",
        sizeof(_firmwareURL) - 1
    );

    Log.info(
        "GITHUB OTA",
        _remoteVersion
    );

    return true;
}


//==============================================================
// Download Firmware
//==============================================================

bool GitHubOTA::downloadFirmware()
{
    String url = _firmwareURL;

    Log.info(
        "GITHUB OTA",
        "Downloading Firmware..."
    );

#if defined(ESP32)

    WiFiClientSecure client;
    client.setInsecure();

    HTTPClient http;

    http.begin(client, url);

    http.setTimeout(30000);

    int httpCode = http.GET();

    if (httpCode != HTTP_CODE_OK)
    {
        Log.printf(
            LogLevel::Error,
            "GITHUB OTA",
            "HTTP Error %d",
            httpCode
        );

        http.end();

        return false;
    }

    String type =
        http.header("Content-Type");

    if (type.indexOf("text/html") >= 0)
    {
        Log.error(
            "GITHUB OTA",
            "Invalid Firmware URL"
        );

        http.end();

        return false;
    }

    int length =
        http.getSize();

    if (length < 50000)
    {
        Log.error(
            "GITHUB OTA",
            "Invalid Firmware Size"
        );

        http.end();

        return false;
    }

    if (!Update.begin(length))
    {
        Log.error(
            "GITHUB OTA",
            "Not Enough Flash"
        );

        http.end();

        return false;
    }

    WiFiClient* stream =
        http.getStreamPtr();

    size_t written =
        Update.writeStream(*stream);

    if (written != (size_t)length)
    {
        Update.abort();

        Log.error(
            "GITHUB OTA",
            "Firmware Write Failed"
        );

        http.end();

        return false;
    }

    http.end();

    if (!Update.end())
    {
        Log.error(
            "GITHUB OTA",
            Update.errorString()
        );

        return false;
    }

    if (!Update.isFinished())
    {
        Log.error(
            "GITHUB OTA",
            "Update Incomplete"
        );

        return false;
    }

    Log.success(
        "GITHUB OTA",
        "Update Successful"
    );

    delay(1000);

    ESP.restart();

    return true;

#elif defined(ESP8266)

    t_httpUpdate_return result =
        ESPhttpUpdate.update(url);

    switch (result)
    {
        case HTTP_UPDATE_OK:

            Log.success(
                "GITHUB OTA",
                "Update Successful"
            );

            return true;

        case HTTP_UPDATE_FAILED:

            Log.error(
                "GITHUB OTA",
                "Update Failed"
            );

            return false;

        case HTTP_UPDATE_NO_UPDATES:

            Log.warning(
                "GITHUB OTA",
                "No Update Available"
            );

            return false;
    }

#endif

    return false;
}