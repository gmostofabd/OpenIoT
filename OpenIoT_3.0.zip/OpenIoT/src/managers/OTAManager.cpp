/*****************************************************************
    OpenIoT Framework

    File        : OTAManager.cpp
    Description : Arduino OTA Manager

    Version     : 2.2.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "OTAManager.h"

#include "LoggerManager.h"
#include "VersionManager.h"

#include <string.h>

#if defined(ESP32)

#include <WiFi.h>
#include <ArduinoOTA.h>

#elif defined(ESP8266)

#include <ESP8266WiFi.h>
#include <ArduinoOTA.h>

#endif

namespace OIF
{

//==============================================================
// Global Instance
//==============================================================

OTAManager OTA;


//==============================================================
// Constructor
//==============================================================

OTAManager::OTAManager()
    : _enabled(false)
    , _waitingForWiFi(false)
{
    strncpy(
        _hostname,
        "OpenIoT",
        sizeof(_hostname) - 1
    );

    _hostname[sizeof(_hostname) - 1] = '\0';
}


//==============================================================
// Initialize OTA
//==============================================================

bool OTAManager::begin()
{

#if defined(ESP32) || defined(ESP8266)

    //----------------------------------------------------------
    // Already Running
    //----------------------------------------------------------

    if (_enabled)
        return true;

    //----------------------------------------------------------
    // Wait for WiFi
    //----------------------------------------------------------

    if (WiFi.status() != WL_CONNECTED)
    {
        if (!_waitingForWiFi)
        {
            Log.info(
                "OTA",
                "Waiting for WiFi..."
            );

            _waitingForWiFi = true;
        }

        return true;
    }

    //----------------------------------------------------------
    // Hostname
    //----------------------------------------------------------

    ArduinoOTA.setHostname(_hostname);

    //----------------------------------------------------------
    // OTA Start Callback
    //----------------------------------------------------------

    ArduinoOTA.onStart(
        []()
        {

#if defined(ESP32)

            if (ArduinoOTA.getCommand() == U_FLASH)
            {
                Log.info(
                    "OTA",
                    "Firmware Update Started"
                );
            }
            else
            {
                Log.info(
                    "OTA",
                    "Filesystem Update Started"
                );
            }

#else

            Log.info(
                "OTA",
                "OTA Update Started"
            );

#endif

        }
    );

    //----------------------------------------------------------
    // OTA End Callback
    //----------------------------------------------------------

    ArduinoOTA.onEnd(
        []()
        {
            Log.success(
                "OTA",
                "OTA Update Completed"
            );
        }
    );

    //----------------------------------------------------------
    // OTA Progress Callback
    //----------------------------------------------------------

    ArduinoOTA.onProgress(
        [](unsigned int progress,
           unsigned int total)
        {
            static uint8_t lastPercent = 255;

            uint8_t percent =
                (total == 0)
                ? 0
                : (progress * 100U) / total;

            if (percent == lastPercent)
                return;

            lastPercent = percent;

            if ((percent % 5) == 0 || percent == 100)
            {
                Log.info(
                    "OTA",
                    "Progress : %u%%",
                    percent
                );
            }
        }
    );


    //----------------------------------------------------------
    // OTA Error Callback
    //----------------------------------------------------------

    ArduinoOTA.onError(
        [](ota_error_t error)
        {
            switch (error)
            {
                case OTA_AUTH_ERROR:

                    Log.error(
                        "OTA",
                        "Authentication Failed"
                    );

                    break;

                case OTA_BEGIN_ERROR:

                    Log.error(
                        "OTA",
                        "Begin Failed"
                    );

                    break;

                case OTA_CONNECT_ERROR:

                    Log.error(
                        "OTA",
                        "Connection Failed"
                    );

                    break;

                case OTA_RECEIVE_ERROR:

                    Log.error(
                        "OTA",
                        "Receive Failed"
                    );

                    break;

                case OTA_END_ERROR:

                    Log.error(
                        "OTA",
                        "End Failed"
                    );

                    break;

                default:

                    Log.error(
                        "OTA",
                        "Unknown Error (%u)",
                        error
                    );

                    break;
            }
        }
    );

    //----------------------------------------------------------
    // Start OTA Service
    //----------------------------------------------------------

    ArduinoOTA.begin();

    _enabled = true;
    _waitingForWiFi = false;

    //----------------------------------------------------------
    // Information
    //----------------------------------------------------------

    String ip = WiFi.localIP().toString();

    Log.success(
        "OTA",
        "Arduino OTA Ready"
    );

    Log.info(
        "OTA",
        "Hostname : %s",
        _hostname
    );

    Log.info(
        "OTA",
        "Firmware : %s",
        Version.version()
    );

    Log.info(
        "OTA",
        "Board : %s",
        OIF_PLATFORM_NAME
    );

    Log.info(
        "OTA",
        "IP : %s",
        ip.c_str()
    );

#else

    Log.warning(
        "OTA",
        "Platform Not Supported"
    );

#endif

    return _enabled;
}


//==============================================================
// OTA Task
//==============================================================

void OTAManager::run()
{

#if defined(ESP32) || defined(ESP8266)

    //----------------------------------------------------------
    // Waiting For WiFi
    //----------------------------------------------------------

    if (!_enabled)
    {
        if (_waitingForWiFi &&
            WiFi.status() == WL_CONNECTED)
        {
            begin();
        }

        return;
    }

    //----------------------------------------------------------
    // Lost WiFi
    //----------------------------------------------------------

    if (WiFi.status() != WL_CONNECTED)
    {
        Log.warning(
            "OTA",
            "WiFi disconnected"
        );

        stop();

        _waitingForWiFi = true;

        return;
    }

    //----------------------------------------------------------
    // Handle OTA
    //----------------------------------------------------------

    ArduinoOTA.handle();

#endif

}


//==============================================================
// Stop OTA
//==============================================================

void OTAManager::stop()
{
    if (!_enabled)
        return;

    _enabled = false;

    _waitingForWiFi = true;

    Log.info(
        "OTA",
        "OTA Disabled"
    );
}


//==============================================================
// Status
//==============================================================

bool OTAManager::enabled() const
{
    return _enabled;
}


//==============================================================
// Waiting For WiFi
//==============================================================

bool OTAManager::waitingForWiFi() const
{
    return _waitingForWiFi;
}


//==============================================================
// Set Hostname
//==============================================================

void OTAManager::setHostname(
    const char* hostname
)
{
    if (hostname == nullptr)
        return;

    strncpy(
        _hostname,
        hostname,
        sizeof(_hostname) - 1
    );

    _hostname[sizeof(_hostname) - 1] = '\0';
}


//==============================================================
// Get Hostname
//==============================================================

const char* OTAManager::hostname() const
{
    return _hostname;
}

} // namespace OIF




