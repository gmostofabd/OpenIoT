#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : OTAManager.h
    Description : Arduino OTA Update Manager

    Version     : 2.1.0

    License     : MIT
*****************************************************************/

#include "../Platform.h"

namespace OIF
{

class OTAManager
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    OTAManager();

    //----------------------------------------------------------
    // Framework Lifecycle
    //----------------------------------------------------------

    bool begin();

    void run();

    void stop();

    //----------------------------------------------------------
    // Status
    //----------------------------------------------------------

    bool enabled() const;

    bool waitingForWiFi() const;

    //----------------------------------------------------------
    // Hostname
    //----------------------------------------------------------

    void setHostname(
        const char* hostname
    );

    const char* hostname() const;

private:

    //----------------------------------------------------------
    // State
    //----------------------------------------------------------

    bool _enabled;

    bool _waitingForWiFi;

    //----------------------------------------------------------
    // OTA Hostname
    //----------------------------------------------------------

    char _hostname[32];
};

extern OTAManager OTA;

} // namespace OIF