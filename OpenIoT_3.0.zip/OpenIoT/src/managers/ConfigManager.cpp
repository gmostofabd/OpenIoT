/*****************************************************************
    OpenIoT Framework

    File        : ConfigManager.cpp
    Description : Configuration Implementation

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "ConfigManager.h"

#include <string.h>

namespace OIF
{

//==============================================================
// Global Instance
//==============================================================

ConfigManager Config;


//==============================================================
// Constructor
//==============================================================

ConfigManager::ConfigManager()
{
    memset(&_device,  0, sizeof(_device));
    memset(&_network, 0, sizeof(_network));
    memset(&_web,     0, sizeof(_web));
    memset(&_github,  0, sizeof(_github));
}


//==============================================================
// Initialize
//==============================================================

bool ConfigManager::begin()
{
    //----------------------------------------------------------
    // Future:
    // Load configuration from LittleFS / EEPROM / Preferences
    //----------------------------------------------------------

    loadDefaults();

    return true;
}


//==============================================================
// Load Default Configuration
//==============================================================

void ConfigManager::loadDefaults()
{
    //----------------------------------------------------------
    // Device Configuration
    //----------------------------------------------------------

    strncpy(
        _device.name,
        "OpenIoT Device",
        sizeof(_device.name) - 1
    );
    _device.name[sizeof(_device.name) - 1] = '\0';

    strncpy(
        _device.version,
        "1.0.0",
        sizeof(_device.version) - 1
    );
    _device.version[sizeof(_device.version) - 1] = '\0';

    //----------------------------------------------------------
    // Network Configuration
    //----------------------------------------------------------

    strncpy(
        _network.ssid,
        "TBD",
        sizeof(_network.ssid) - 1
    );
    _network.ssid[sizeof(_network.ssid) - 1] = '\0';

    strncpy(
        _network.password,
        "01929512976",
        sizeof(_network.password) - 1
    );
    _network.password[sizeof(_network.password) - 1] = '\0';

    strncpy(
        _network.hostname,
        "openiot-device",
        sizeof(_network.hostname) - 1
    );
    _network.hostname[sizeof(_network.hostname) - 1] = '\0';

    //----------------------------------------------------------
    // Web Configuration
    //----------------------------------------------------------

    _web.port = 80;

    //----------------------------------------------------------
    // GitHub OTA Configuration
    //----------------------------------------------------------

    strncpy(
        _github.owner,
        "gmostofabd",
        sizeof(_github.owner) - 1
    );
    _github.owner[sizeof(_github.owner) - 1] = '\0';

    strncpy(
        _github.repository,
        "OpenIoT-Framework",
        sizeof(_github.repository) - 1
    );
    _github.repository[sizeof(_github.repository) - 1] = '\0';

    strncpy(
        _github.branch,
        "main",
        sizeof(_github.branch) - 1
    );
    _github.branch[sizeof(_github.branch) - 1] = '\0';

    strncpy(
        _github.channel,
        "stable",
        sizeof(_github.channel) - 1
    );
    _github.channel[sizeof(_github.channel) - 1] = '\0';
}


//==============================================================
// Reset Configuration
//==============================================================

void ConfigManager::reset()
{
    loadDefaults();
}


//==============================================================
// Device Configuration
//==============================================================

const DeviceConfig&
ConfigManager::device() const
{
    return _device;
}


//==============================================================
// Network Configuration
//==============================================================

const NetworkConfig&
ConfigManager::network() const
{
    return _network;
}


//==============================================================
// Web Configuration
//==============================================================

const WebConfig&
ConfigManager::web() const
{
    return _web;
}


//==============================================================
// GitHub OTA Configuration
//==============================================================

const GitHubConfig&
ConfigManager::github() const
{
    return _github;
}

} // namespace OIF