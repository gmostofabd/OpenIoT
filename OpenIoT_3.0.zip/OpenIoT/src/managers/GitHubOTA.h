#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : GitHubOTA.h
    Description : GitHub Firmware Update Engine

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#ifndef GITHUB_OTA_H
#define GITHUB_OTA_H

#include "../Platform.h"

namespace OIF
{

//==============================================================
// GitHub OTA Manager
//==============================================================

class GitHubOTA
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    GitHubOTA();

    //----------------------------------------------------------
    // Initialization
    //----------------------------------------------------------

    bool begin();

    //----------------------------------------------------------
    // OTA Operations
    //----------------------------------------------------------

    bool checkVersion();

    bool update();

    //----------------------------------------------------------
    // Information
    //----------------------------------------------------------

    const char* remoteVersion() const;

    const char* firmwareURL() const;

    bool updateAvailable() const;

private:

    //----------------------------------------------------------
    // Remote Firmware Information
    //----------------------------------------------------------

    char _remoteVersion[16];

    char _firmwareURL[160];

    //----------------------------------------------------------
    // Internal Functions
    //----------------------------------------------------------

    bool downloadVersionFile(
        String& json
    );

    bool parseVersion(
        const String& json
    );

    bool downloadFirmware();

};


//==============================================================
// Global Instance
//==============================================================

extern GitHubOTA GitHubUpdate;

} // namespace OIF

#endif