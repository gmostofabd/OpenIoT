#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : VersionManager.h
    Description : Firmware Version Management

    Version     : 1.0.0

    License     : MIT
*****************************************************************/

#include "../Platform.h"

namespace OIF
{

//==============================================================
// FIRMWARE INFORMATION
//==============================================================

struct FirmwareInfo
{
    char name[32];
    char version[16];

    uint32_t build;

    char buildDate[16];
    char buildTime[16];

    char channel[16];

    char board[32];
    char architecture[16];

    char firmwareURL[128];
};


//==============================================================
// VERSION MANAGER
//==============================================================

class VersionManager
{
public:

    VersionManager();

    //----------------------------------------------------------
    // Initialization
    //----------------------------------------------------------

    bool begin();

    //----------------------------------------------------------
    // Information
    //----------------------------------------------------------

    const FirmwareInfo& info() const;

    const char* name() const;

    const char* version() const;

    const char* channel() const;

    const char* buildDate() const;

    const char* buildTime() const;

    const char* board() const;

    const char* architecture() const;

    const char* firmwareURL() const;

    uint32_t build() const;

    //----------------------------------------------------------
    // OTA Version Control
    //----------------------------------------------------------

    void setRemoteVersion(
        const char* version
    );

    const char* remoteVersion() const;

    bool isNewer(
        const char* remoteVersion
    ) const;

private:

    //----------------------------------------------------------
    // Version Compare
    //
    // Returns:
    //  -1 : Local < Remote
    //   0 : Equal
    //   1 : Local > Remote
    //----------------------------------------------------------

    int compareVersion(
        const char* local,
        const char* remote
    ) const;

private:

    FirmwareInfo _info;

    char _remoteVersion[16];
};


//==============================================================
// GLOBAL INSTANCE
//==============================================================

extern VersionManager Version;

} // namespace OIF