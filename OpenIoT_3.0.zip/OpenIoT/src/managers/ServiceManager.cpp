/*****************************************************************
    OpenIoT Framework

    File        : ServiceManager.cpp
    Description : Base Service Manager

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "ServiceManager.h"

namespace OIF
{

//==============================================================
// Service Constructor
//==============================================================

Service::Service(
    ServiceId id,
    const char* name
)
{
    _id = id;
    _name = name;
    _enabled = true;
}


//==============================================================
// Service Registry Constructor
//==============================================================

ServiceRegistry::ServiceRegistry()
{
    _count = 0;

    for (uint8_t i = 0;
         i < MAX_SERVICES;
         i++)
    {
        _services[i] = nullptr;
    }
}


//==============================================================
// Add Service
//==============================================================

Result ServiceRegistry::add(
    Service* service
)
{
    if (service == nullptr)
    {
        return Result::INVALID_PARAMETER;
    }

    if (_count >= MAX_SERVICES)
    {
        return Result::BUSY;
    }

    //----------------------------------------------------------
    // Prevent duplicate pointer
    //----------------------------------------------------------

    for (uint8_t i = 0;
         i < _count;
         i++)
    {
        if (_services[i] == service)
        {
            return Result::OK;
        }
    }

    //----------------------------------------------------------
    // Prevent duplicate Service ID
    //----------------------------------------------------------

    for (uint8_t i = 0;
         i < _count;
         i++)
    {
        if (_services[i] == nullptr)
            continue;

        if (_services[i]->id() == service->id())
        {
            return Result::ALREADY_EXISTS;
        }
    }

    _services[_count] = service;

    _count++;

    return Result::OK;
}


//==============================================================
// Remove Service
//==============================================================

Result ServiceRegistry::remove(
    Service* service
)
{
    if (service == nullptr)
    {
        return Result::INVALID_PARAMETER;
    }

    for (uint8_t i = 0;
         i < _count;
         i++)
    {
        if (_services[i] != service)
            continue;

        for (uint8_t j = i;
             j < (_count - 1);
             j++)
        {
            _services[j] = _services[j + 1];
        }

        _services[_count - 1] = nullptr;

        _count--;

        return Result::OK;
    }

    return Result::NOT_FOUND;
}


//==============================================================
// Find Service
//==============================================================

Service* ServiceRegistry::find(
    ServiceId id
) const
{
    for (uint8_t i = 0;
         i < _count;
         i++)
    {
        if (_services[i] == nullptr)
            continue;

        if (_services[i]->id() == id)
        {
            return _services[i];
        }
    }

    return nullptr;
}


//==============================================================
// Get Service By Index
//==============================================================

Service* ServiceRegistry::get(
    uint8_t index
) const
{
    if (index >= _count)
    {
        return nullptr;
    }

    return _services[index];
}


//==============================================================
// Service Count
//==============================================================

uint8_t ServiceRegistry::count() const
{
    return _count;
}

} // namespace OIF