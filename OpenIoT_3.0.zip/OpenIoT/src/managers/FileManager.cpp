/*****************************************************************
    OpenIoT Framework

    File        : FileManager.cpp
    Description : LittleFS File Manager

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "FileManager.h"

#include "LoggerManager.h"

namespace OIF
{

//==============================================================
// GLOBAL INSTANCE
//==============================================================

FileManager Storage;


//==============================================================
// Constructor
//==============================================================

FileManager::FileManager()
{
    _mounted = false;
}


//==============================================================
// Initialize LittleFS
//==============================================================

bool FileManager::begin()
{
    if (_mounted)
        return true;

    Log.info(
        "FILE",
        "Initializing LittleFS"
    );

#if defined(ESP32)

    _mounted = LittleFS.begin(true);

#elif defined(ESP8266)

    _mounted = LittleFS.begin();

#endif

    if (_mounted)
    {
        Log.success(
            "FILE",
            "LittleFS Mounted"
        );
    }
    else
    {
        Log.error(
            "FILE",
            "LittleFS Mount Failed"
        );
    }

    return _mounted;
}


//==============================================================
// Shutdown
//==============================================================

void FileManager::stop()
{
    if (!_mounted)
        return;

    LittleFS.end();

    _mounted = false;

    Log.info(
        "FILE",
        "LittleFS Unmounted"
    );
}


//==============================================================
// Mounted Status
//==============================================================

bool FileManager::mounted() const
{
    return _mounted;
}


//==============================================================
// Check File Exists
//==============================================================

bool FileManager::exists(
    const char* path
)
{
    if (!_mounted || path == nullptr)
        return false;

    return LittleFS.exists(path);
}


//==============================================================
// Read File
//==============================================================

String FileManager::read(
    const char* path
)
{
    if (!_mounted || path == nullptr)
        return "";

    File file =
        LittleFS.open(
            path,
            "r"
        );

    if (!file)
    {
        Log.error(
            "FILE",
            "Open Failed : %s",
            path
        );

        return "";
    }

    String data;

    data.reserve(
        file.size()
    );

    data =
        file.readString();

    file.close();

    return data;
}


//==============================================================
// Write File
//==============================================================

bool FileManager::write(
    const char* path,
    const String& data
)
{
    if (!_mounted || path == nullptr)
        return false;

    File file =
        LittleFS.open(
            path,
            "w"
        );

    if (!file)
    {
        Log.error(
            "FILE",
            "Write Failed : %s",
            path
        );

        return false;
    }

    size_t written =
        file.print(data);

    file.close();

    return (written == data.length());
}


//==============================================================
// Delete File
//==============================================================

bool FileManager::removeFile(
    const char* path
)
{
    if (!_mounted || path == nullptr)
        return false;

    return LittleFS.remove(path);
}


//==============================================================
// Format Filesystem
//==============================================================

bool FileManager::format()
{
    Log.warning(
        "FILE",
        "Formatting LittleFS..."
    );

    return LittleFS.format();
}


//==============================================================
// Total Space
//==============================================================

uint32_t FileManager::totalSpace()
{
    if (!_mounted)
        return 0;

#if defined(ESP32)

    return LittleFS.totalBytes();

#elif defined(ESP8266)

    FSInfo info;

    LittleFS.info(info);

    return info.totalBytes;

#else

    return 0;

#endif
}


//==============================================================
// Used Space
//==============================================================

uint32_t FileManager::usedSpace()
{
    if (!_mounted)
        return 0;

#if defined(ESP32)

    return LittleFS.usedBytes();

#elif defined(ESP8266)

    FSInfo info;

    LittleFS.info(info);

    return info.usedBytes;

#else

    return 0;

#endif
}

} // namespace OIF