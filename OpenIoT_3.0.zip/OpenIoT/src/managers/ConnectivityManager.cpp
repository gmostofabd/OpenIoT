/*****************************************************************
    OpenIoT Framework

    File        : ConnectivityManager.cpp
    Description : WiFi Connectivity Manager

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "ConnectivityManager.h"

#include "LoggerManager.h"
#include "ConfigManager.h"

namespace OIF
{

//==============================================================
// GLOBAL INSTANCE
//==============================================================

ConnectivityManager Connectivity;


//==============================================================
// Constructor
//==============================================================

ConnectivityManager::ConnectivityManager()
{
    _lastReconnect = 0;
}


//==============================================================
// Initialize
//==============================================================

bool ConnectivityManager::begin()
{
    Log.info(
        "WIFI",
        "Initializing WiFi"
    );

#if defined(ESP32)
    WiFi.mode(WIFI_STA);
#endif

    connect();

    return connected();
}


//==============================================================
// Main Task
//==============================================================

void ConnectivityManager::run()
{
    if (connected())
        return;

    if (millis() - _lastReconnect < 10000)
        return;

    _lastReconnect = millis();

    Log.warning(
        "WIFI",
        "Connection Lost - Reconnecting..."
    );

    reconnect();
}


//==============================================================
// Connect
//==============================================================

void ConnectivityManager::connect()
{
    const NetworkConfig& cfg =
        Config.network();

    if (strlen(cfg.ssid) == 0)
    {
        Log.error(
            "WIFI",
            "SSID Not Configured"
        );

        return;
    }

    Log.info(
        "WIFI",
        "Connecting to %s",
        cfg.ssid
    );

    WiFi.begin(
        cfg.ssid,
        cfg.password
    );

    unsigned long start = millis();

    while (
        WiFi.status() != WL_CONNECTED &&
        millis() - start < 15000
    )
    {
        delay(250);
    }

    if (connected())
    {
        Log.success(
            "WIFI",
            "Connected"
        );

        Log.info(
            "WIFI",
            "IP : %s",
            WiFi.localIP().toString().c_str()
        );
    }
    else
    {
        Log.error(
            "WIFI",
            "Connection Failed"
        );
    }
}


//==============================================================
// Disconnect
//==============================================================

void ConnectivityManager::disconnect()
{
    WiFi.disconnect(true);

    Log.info(
        "WIFI",
        "Disconnected"
    );
}


//==============================================================
// Reconnect
//==============================================================

void ConnectivityManager::reconnect()
{
    disconnect();

    delay(500);

    connect();
}


//==============================================================
// Connected
//==============================================================

bool ConnectivityManager::connected() const
{
    return WiFi.status() == WL_CONNECTED;
}


bool ConnectivityManager::isConnected() const
{
    return connected();
}


//==============================================================
// IP Address
//==============================================================

String ConnectivityManager::ipAddress() const
{
    if (!connected())
        return "0.0.0.0";

    return WiFi.localIP().toString();
}


//==============================================================
// MAC Address
//==============================================================

String ConnectivityManager::macAddress() const
{
    return WiFi.macAddress();
}


//==============================================================
// SSID
//==============================================================

String ConnectivityManager::ssid() const
{
    return WiFi.SSID();
}


//==============================================================
// Signal Strength
//==============================================================

int ConnectivityManager::signalStrength() const
{
    if (!connected())
        return 0;

    return WiFi.RSSI();
}


//==============================================================
// Last Reconnect Time
//==============================================================

unsigned long ConnectivityManager::reconnectTime() const
{
    return _lastReconnect;
}

} // namespace OIF