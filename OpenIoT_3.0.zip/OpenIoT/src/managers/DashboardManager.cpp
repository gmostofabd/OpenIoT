/*****************************************************************
    OpenIoT Framework

    File        : DashboardManager.cpp
    Description : Dashboard Manager

    Version     : 2.0.0

    License     : MIT
*****************************************************************/

#include "DashboardManager.h"

#include "LoggerManager.h"
#include "VersionManager.h"

namespace OIF
{

DashboardManager Dashboard;

/*********************************************************
    Constructor
*********************************************************/

DashboardManager::DashboardManager()
{
}


/*********************************************************
    Initialize
*********************************************************/

bool DashboardManager::begin()
{
    Log.info(
        "DASH",
        "Dashboard Initialized"
    );

    return true;
}


/*********************************************************
    Main Task
*********************************************************/

void DashboardManager::run()
{
    // Reserved for future dashboard tasks
}


/*********************************************************
    Shutdown
*********************************************************/

void DashboardManager::stop()
{
    Log.info(
        "DASH",
        "Dashboard Stopped"
    );
}


/*********************************************************
    Dashboard HTML
*********************************************************/

String DashboardManager::html() const
{
    String page;

    page.reserve(2048);

    page += F(
        "<!DOCTYPE html>"
        "<html>"
        "<head>"
        "<meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<title>OpenIoT Framework</title>"
        "<style>"
        "body{font-family:Arial;background:#f5f5f5;margin:0;padding:40px;text-align:center;}"
        "h1{color:#1565C0;}"
        ".card{max-width:600px;margin:auto;background:#fff;padding:25px;"
        "border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.15);}"
        "table{width:100%;border-collapse:collapse;margin-top:20px;}"
        "td{padding:8px;border-bottom:1px solid #ddd;text-align:left;}"
        "</style>"
        "</head>"
        "<body>"
        "<div class='card'>"
    );

    page += "<h1>";
    page += Version.name();
    page += "</h1>";

    page += "<table>";

    page += "<tr><td>Version</td><td>";
    page += Version.version();
    page += "</td></tr>";

    page += "<tr><td>Build</td><td>";
    page += String(Version.build());
    page += "</td></tr>";

    page += "<tr><td>Channel</td><td>";
    page += Version.channel();
    page += "</td></tr>";

    page += "<tr><td>Architecture</td><td>";
    page += Version.architecture();
    page += "</td></tr>";

    page += "<tr><td>Board</td><td>";
    page += Version.board();
    page += "</td></tr>";

    page += "</table>";

    page +=
        "<p style='margin-top:25px;'>"
        "OpenIoT Framework is running successfully."
        "</p>";

    page +=
        "</div>"
        "</body>"
        "</html>";

    return page;
}

} // namespace OIF