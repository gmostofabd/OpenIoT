/*****************************************************************
    OpenIoT Framework

    File        : VersionManager.cpp
    Description : Firmware Version Management

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "VersionManager.h"

#include <Arduino.h>
#include <string.h>
#include <stdlib.h>

namespace OIF
{

//==============================================================
// Global Instance
//==============================================================

VersionManager Version;


//==============================================================
// Constructor
//==============================================================

VersionManager::VersionManager()
{
    memset(&_info, 0, sizeof(_info));
    memset(_remoteVersion, 0, sizeof(_remoteVersion));
}


//==============================================================
// Initialize
//==============================================================

bool VersionManager::begin()
{
    strncpy(_info.name,
            "OpenIoT Framework",
            sizeof(_info.name) - 1);

    strncpy(_info.version,
            "1.0.0",
            sizeof(_info.version) - 1);

    _info.build = 1;

    strncpy(_info.buildDate,
            __DATE__,
            sizeof(_info.buildDate) - 1);

    strncpy(_info.buildTime,
            __TIME__,
            sizeof(_info.buildTime) - 1);

    strncpy(_info.channel,
            "Stable",
            sizeof(_info.channel) - 1);

#if defined(ESP32)

    strncpy(_info.board,
            "ESP32",
            sizeof(_info.board) - 1);

    strncpy(_info.architecture,
            "Xtensa",
            sizeof(_info.architecture) - 1);

#elif defined(ESP8266)

    strncpy(_info.board,
            "ESP8266",
            sizeof(_info.board) - 1);

    strncpy(_info.architecture,
            "Xtensa LX106",
            sizeof(_info.architecture) - 1);

#else

    strncpy(_info.board,
            "Unknown",
            sizeof(_info.board) - 1);

    strncpy(_info.architecture,
            "Unknown",
            sizeof(_info.architecture) - 1);

#endif

    strncpy(_info.firmwareURL,
            "",
            sizeof(_info.firmwareURL) - 1);

    return true;
}


//==============================================================
// Information
//==============================================================

const FirmwareInfo& VersionManager::info() const
{
    return _info;
}

const char* VersionManager::name() const
{
    return _info.name;
}

const char* VersionManager::version() const
{
    return _info.version;
}

const char* VersionManager::channel() const
{
    return _info.channel;
}

const char* VersionManager::buildDate() const
{
    return _info.buildDate;
}

const char* VersionManager::buildTime() const
{
    return _info.buildTime;
}

const char* VersionManager::board() const
{
    return _info.board;
}

const char* VersionManager::architecture() const
{
    return _info.architecture;
}

const char* VersionManager::firmwareURL() const
{
    return _info.firmwareURL;
}

uint32_t VersionManager::build() const
{
    return _info.build;
}


//==============================================================
// Remote Version
//==============================================================

void VersionManager::setRemoteVersion(
    const char* version
)
{
    if(version == nullptr)
        return;

    strncpy(_remoteVersion,
            version,
            sizeof(_remoteVersion) - 1);

    _remoteVersion[
        sizeof(_remoteVersion) - 1
    ] = '\0';
}

const char* VersionManager::remoteVersion() const
{
    return _remoteVersion;
}


//==============================================================
// Version Compare
//==============================================================

bool VersionManager::isNewer(
    const char* remoteVersion
) const
{
    if(remoteVersion == nullptr)
        return false;

    return compareVersion(
        _info.version,
        remoteVersion
    ) < 0;
}


int VersionManager::compareVersion(
    const char* local,
    const char* remote
) const
{
    int l1 = 0;
    int l2 = 0;
    int l3 = 0;

    int r1 = 0;
    int r2 = 0;
    int r3 = 0;

    sscanf(local,
           "%d.%d.%d",
           &l1,
           &l2,
           &l3);

    sscanf(remote,
           "%d.%d.%d",
           &r1,
           &r2,
           &r3);

    if(l1 != r1)
        return (l1 < r1) ? -1 : 1;

    if(l2 != r2)
        return (l2 < r2) ? -1 : 1;

    if(l3 != r3)
        return (l3 < r3) ? -1 : 1;

    return 0;
}

} // namespace OIF