/*****************************************************************
        SPSAS V7

        MQTT Manager
*****************************************************************/

#include "MQTTManager.h"

#include <WiFi.h>
#include <PubSubClient.h>

#include "MQTTConfig.h"

#include "../JSON/JSONManager.h"
#include "../Control/ControlManager.h"

WiFiClient wifiClient;

PubSubClient mqtt(wifiClient);

bool mqttConnected=false;

unsigned long mqttTimer=0;







void mqttCallback(char* topic, byte* payload, unsigned int length)
{
    String message;

    for(unsigned int i=0;i<length;i++)
        message+=(char)payload[i];

    String t(topic);

    if(t=="SPSAS/control/pump")
        CONTROL_setPump(message=="ON");

    else if(t=="SPSAS/control/fan")
        CONTROL_setFan(message=="ON");

    else if(t=="SPSAS/control/light")
        CONTROL_setLight(message=="ON");

    else if(t=="SPSAS/control/heater")
        CONTROL_setHeater(message=="ON");

    else if(t=="SPSAS/control/aerator")
        CONTROL_setAerator(message=="ON");
}





void MQTT_begin()
{
    mqtt.setServer(MQTT_SERVER, MQTT_PORT);

    mqtt.setCallback(mqttCallback);
}


void MQTT_update()
{
    if(!mqtt.connected())
    {
        mqttConnected=false;

        if(mqtt.connect(MQTT_CLIENT_ID,
                        MQTT_USER,
                        MQTT_PASSWORD))
        {
            mqttConnected=true;

            mqtt.subscribe("SPSAS/control/pump");

            mqtt.subscribe("SPSAS/control/fan");

            mqtt.subscribe("SPSAS/control/light");

            mqtt.subscribe("SPSAS/control/heater");

            mqtt.subscribe("SPSAS/control/aerator");
        }

        return;
    }

    mqtt.loop();

    if(millis()-mqttTimer>5000)
    {
        mqttTimer=millis();

        MQTT_publishSensors();

        MQTT_publishStatus();
    }
}

void MQTT_publishSensors()
{
    mqtt.publish(
        "SPSAS/json",
        JSON_getJSON().c_str()
    );
}






void MQTT_publishStatus()
{
    mqtt.publish(
        "SPSAS/status",
        "ONLINE"
    );
}


void MQTT_publishGraph()
{
    mqtt.publish(
        "SPSAS/graph",
        JSON_getJSON().c_str()
    );
}



bool MQTT_isConnected()
{
    return mqtt.connected();
}