#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : WebManager.h
    Description : Embedded Web Server Manager

    Version     : 1.0.0

    License     : MIT
*****************************************************************/

#include "../Platform.h"

namespace OIF
{

class WebManager
{
public:

    WebManager();

    //----------------------------------------------------------
    // Lifecycle
    //----------------------------------------------------------

    bool begin();

    void run();

    void stop();

    //----------------------------------------------------------
    // Status
    //----------------------------------------------------------

    bool isRunning() const
    {
        return _running;
    }

    bool isWaiting() const
    {
        return _waitingForWiFi;
    }

private:

#if defined(ESP32)

    WebServer _server;

#elif defined(ESP8266)

    ESP8266WebServer _server;

#endif

    //----------------------------------------------------------
    // State
    //----------------------------------------------------------

    bool _running;
    bool _waitingForWiFi;
    bool _routesRegistered;

    //----------------------------------------------------------
    // Internal
    //----------------------------------------------------------

    void registerRoutes();

    void sendJSON(
        const String& json,
        int code = 200
    );

    //----------------------------------------------------------
    // Route Handlers
    //----------------------------------------------------------

    void handleRoot();
    void handleSystem();
    void handleDevice();
    void handleNetwork();
    void handleHealth();
    void handleVersion();
    void handle404();
};

extern WebManager Web;

} // namespace OIF