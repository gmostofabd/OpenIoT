#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : FileManager.h
    Description : LittleFS File Manager

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "../Platform.h"

namespace OIF
{

//==============================================================
// FILE MANAGER
//==============================================================

class FileManager
{
public:

    FileManager();

    //----------------------------------------------------------
    // Initialization
    //----------------------------------------------------------

    bool begin();

    void stop();

    //----------------------------------------------------------
    // Status
    //----------------------------------------------------------

    bool mounted() const;

    //----------------------------------------------------------
    // File Operations
    //----------------------------------------------------------

    bool exists(const char* path);

    String read(const char* path);

    bool write(
        const char* path,
        const String& data
    );

    bool removeFile(
        const char* path
    );

    //----------------------------------------------------------
    // Filesystem
    //----------------------------------------------------------

    bool format();

    uint32_t totalSpace();

    uint32_t usedSpace();

private:

    bool _mounted;
};


//==============================================================
// GLOBAL INSTANCE
//==============================================================

extern FileManager Storage;

} // namespace OIF