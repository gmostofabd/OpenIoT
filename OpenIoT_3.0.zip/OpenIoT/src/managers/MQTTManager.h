#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : MQTTManager.h
    Description : MQTT Communication Manager

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#ifndef OIF_MQTT_MANAGER_H
#define OIF_MQTT_MANAGER_H

#include "../Platform.h"

#include <WiFiClient.h>
#include <PubSubClient.h>

namespace OIF
{

//==============================================================
// MQTT Manager
//==============================================================

class MQTTManager
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    MQTTManager();

    //----------------------------------------------------------
    // Framework Lifecycle
    //----------------------------------------------------------

    bool begin();

    void run();

    void stop();

    //----------------------------------------------------------
    // Connection Status
    //----------------------------------------------------------

    bool connected() const;

    //----------------------------------------------------------
    // Publish
    //----------------------------------------------------------

    bool publish(
        const char* topic,
        const char* payload,
        bool retained = false
    );

    //----------------------------------------------------------
    // Subscribe
    //----------------------------------------------------------

    bool subscribe(
        const char* topic
    );

    //----------------------------------------------------------
    // Broker Information
    //----------------------------------------------------------

    const char* host() const;

    uint16_t port() const;

    const char* clientId() const;

private:

    //----------------------------------------------------------
    // MQTT Client
    //----------------------------------------------------------

    WiFiClient _wifiClient;

    PubSubClient _client;

    //----------------------------------------------------------
    // Internal State
    //----------------------------------------------------------

    bool _enabled;

    bool _waitingForWiFi;

    unsigned long _lastReconnect;

    //----------------------------------------------------------
    // Internal Functions
    //----------------------------------------------------------

    bool connect();

    static void callback(
        char* topic,
        byte* payload,
        unsigned int length
    );
};


//==============================================================
// Global Instance
//==============================================================

extern MQTTManager MQTT;

} // namespace OIF

#endif // OIF_MQTT_MANAGER_H