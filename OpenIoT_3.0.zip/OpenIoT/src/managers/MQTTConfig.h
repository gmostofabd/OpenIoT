#ifndef MQTT_CONFIG_H
#define MQTT_CONFIG_H

#define MQTT_SERVER     "broker.hivemq.com"
#define MQTT_PORT       1883

#define MQTT_USER       ""
#define MQTT_PASSWORD   ""

#define MQTT_CLIENT_ID  "SPSAS_ESP32"

#endif