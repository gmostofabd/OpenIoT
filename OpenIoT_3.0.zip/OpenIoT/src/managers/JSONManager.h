#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : JSONManager.h
    Description : JSON Data Manager

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "../Platform.h"

#include <ArduinoJson.h>

namespace OIF
{

//==============================================================
// JSON Manager
//==============================================================

class JSONManager
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    JSONManager();

    //----------------------------------------------------------
    // Initialization
    //----------------------------------------------------------

    bool begin();

    //----------------------------------------------------------
    // JSON Generators
    //----------------------------------------------------------

    String systemJSON();

    String deviceJSON();

    String networkJSON();

private:

    //----------------------------------------------------------
    // JSON Builders
    //----------------------------------------------------------

    void addSystemData(
        JsonDocument& doc
    );

    void addDeviceData(
        JsonDocument& doc
    );

    void addNetworkData(
        JsonDocument& doc
    );
};


//==============================================================
// Global Instance
//==============================================================

extern JSONManager JSON;

} // namespace OIF