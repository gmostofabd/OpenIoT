/*****************************************************************
    OpenIoT Framework

    File        : LoggerManager.cpp
    Description : Logging Manager

    Version     : 2.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "LoggerManager.h"

#include <stdarg.h>
#include <stdio.h>

namespace OIF
{

//==============================================================
// Global Instance
//==============================================================

LoggerManager Log;


//==============================================================
// Constructor
//==============================================================

LoggerManager::LoggerManager()
{
    _level = LogLevel::Info;
}


//==============================================================
// Initialize
//==============================================================

bool LoggerManager::begin()
{
    info(
        "LOGGER",
        "Logger Initialized"
    );

    return true;
}


//==============================================================
// Main Task
//==============================================================

void LoggerManager::run()
{
    // Reserved for future use
}


//==============================================================
// Shutdown
//==============================================================

void LoggerManager::stop()
{
    info(
        "LOGGER",
        "Logger Stopped"
    );
}


//==============================================================
// Log Level
//==============================================================

void LoggerManager::setLevel(
    LogLevel level
)
{
    _level = level;
}


LogLevel LoggerManager::level() const
{
    return _level;
}


//==============================================================
// Prefix
//==============================================================

void LoggerManager::printPrefix(
    LogLevel level,
    const char* module
)
{
    switch (level)
    {
        case LogLevel::Error:
            Serial.print("[ERROR]");
            break;

        case LogLevel::Warning:
            Serial.print("[WARN ]");
            break;

        case LogLevel::Success:
            Serial.print("[ OK  ]");
            break;

        case LogLevel::Info:
            Serial.print("[INFO ]");
            break;

        case LogLevel::Debug:
            Serial.print("[DEBUG]");
            break;

        default:
            Serial.print("[LOG  ]");
            break;
    }

    Serial.print('[');
    Serial.print(module);
    Serial.print("] ");
}


//==============================================================
// Internal Print
//==============================================================

void LoggerManager::vprint(
    LogLevel level,
    const char* module,
    const char* format,
    va_list args
)
{
    if (_level < level)
        return;

    char buffer[256];

    vsnprintf(
        buffer,
        sizeof(buffer),
        format,
        args
    );

    printPrefix(
        level,
        module
    );

    Serial.println(buffer);
}


//==============================================================
// Error
//==============================================================

void LoggerManager::error(
    const char* module,
    const char* format,
    ...
)
{
    va_list args;

    va_start(args, format);

    vprint(
        LogLevel::Error,
        module,
        format,
        args
    );

    va_end(args);
}


//==============================================================
// Warning
//==============================================================

void LoggerManager::warning(
    const char* module,
    const char* format,
    ...
)
{
    va_list args;

    va_start(args, format);

    vprint(
        LogLevel::Warning,
        module,
        format,
        args
    );

    va_end(args);
}


//==============================================================
// Success
//==============================================================

void LoggerManager::success(
    const char* module,
    const char* format,
    ...
)
{
    va_list args;

    va_start(args, format);

    vprint(
        LogLevel::Success,
        module,
        format,
        args
    );

    va_end(args);
}


//==============================================================
// Info
//==============================================================

void LoggerManager::info(
    const char* module,
    const char* format,
    ...
)
{
    va_list args;

    va_start(args, format);

    vprint(
        LogLevel::Info,
        module,
        format,
        args
    );

    va_end(args);
}


//==============================================================
// Debug
//==============================================================

void LoggerManager::debug(
    const char* module,
    const char* format,
    ...
)
{
    va_list args;

    va_start(args, format);

    vprint(
        LogLevel::Debug,
        module,
        format,
        args
    );

    va_end(args);
}

} // namespace OIF