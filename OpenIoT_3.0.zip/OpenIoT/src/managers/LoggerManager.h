#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : LoggerManager.h
    Description : Logging Manager

    Version     : 2.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#ifndef LOGGER_MANAGER_H
#define LOGGER_MANAGER_H

#include "../Platform.h"

#include <stdarg.h>

namespace OIF
{

//==============================================================
// LOG LEVELS
//==============================================================

enum class LogLevel : uint8_t
{
    None = 0,
    Error,
    Warning,
    Success,
    Info,
    Debug
};


//==============================================================
// LOGGER MANAGER
//==============================================================

class LoggerManager
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    LoggerManager();

    //----------------------------------------------------------
    // Initialization
    //----------------------------------------------------------

    bool begin();

    //----------------------------------------------------------
    // Main Task
    //----------------------------------------------------------

    void run();

    //----------------------------------------------------------
    // Shutdown
    //----------------------------------------------------------

    void stop();

    //----------------------------------------------------------
    // Configuration
    //----------------------------------------------------------

    void setLevel(
        LogLevel level
    );

    LogLevel level() const;

    //----------------------------------------------------------
    // Logging
    //----------------------------------------------------------

    void error(
        const char* module,
        const char* format,
        ...
    );

    void warning(
        const char* module,
        const char* format,
        ...
    );

    void success(
        const char* module,
        const char* format,
        ...
    );

    void info(
        const char* module,
        const char* format,
        ...
    );

    void debug(
        const char* module,
        const char* format,
        ...
    );

    //----------------------------------------------------------
    // Generic Print
    //----------------------------------------------------------

    void printf(
        LogLevel level,
        const char* module,
        const char* format,
        ...
    );

private:

    //----------------------------------------------------------
    // Internal Helper
    //----------------------------------------------------------

    void printPrefix(
        LogLevel level,
        const char* module
    );

    void vprint(
        LogLevel level,
        const char* module,
        const char* format,
        va_list args
    );

private:

    LogLevel _level;

};


//==============================================================
// GLOBAL LOGGER
//==============================================================

extern LoggerManager Log;

} // namespace OIF

#endif