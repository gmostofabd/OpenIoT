/*****************************************************************
    OpenIoT Framework

    File        : ConnectivityManager.cpp
    Description : WiFi Connectivity Manager

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "ConnectivityManager.h"

#include "ConfigManager.h"
#include "LoggerManager.h"

namespace OIF
{

//==============================================================
// Global Instance
//==============================================================

ConnectivityManager Connectivity;


//==============================================================
// Constructor
//==============================================================

ConnectivityManager::ConnectivityManager()
{
    _lastReconnect = 0;
}


//==============================================================
// Initialize
//==============================================================

bool ConnectivityManager::begin()
{
    Log.info(
        "NET",
        "Initializing WiFi"
    );

#if defined(ESP32)

    WiFi.mode(WIFI_STA);

#elif defined(ESP8266)

    WiFi.mode(WIFI_STA);

#endif

    connect();

    return connected();
}


//==============================================================
// Main Loop
//==============================================================

void ConnectivityManager::run()
{
    if (connected())
        return;

    if (millis() - _lastReconnect >= 10000)
    {
        reconnect();
    }
}


//==============================================================
// Connect
//==============================================================

void ConnectivityManager::connect()
{
    const NetworkConfig& cfg =
        Config.network();

    _lastReconnect = millis();

    Log.info(
        "NET",
        "Connecting to %s",
        cfg.ssid
    );

#if defined(ESP32)

    WiFi.setHostname(cfg.hostname);

#elif defined(ESP8266)

    WiFi.hostname(cfg.hostname);

#endif

    WiFi.begin(
        cfg.ssid,
        cfg.password
    );

    unsigned long start = millis();

    while (!connected() &&
           millis() - start < 15000)
    {
        delay(250);
    }

    if (connected())
    {
        Log.success(
            "NET",
            "Connected"
        );

        Log.info(
            "NET",
            "IP : %s",
            WiFi.localIP().toString().c_str()
        );
    }
    else
    {
        Log.warning(
            "NET",
            "Connection Failed"
        );
    }
}


//==============================================================
// Disconnect
//==============================================================

void ConnectivityManager::disconnect()
{
    WiFi.disconnect(true);

    Log.info(
        "NET",
        "Disconnected"
    );
}


//==============================================================
// Reconnect
//==============================================================

void ConnectivityManager::reconnect()
{
    Log.warning(
        "NET",
        "Reconnecting..."
    );

    disconnect();

    delay(100);

    connect();
}


//==============================================================
// Connected
//==============================================================

bool ConnectivityManager::connected() const
{
    return WiFi.status() == WL_CONNECTED;
}


bool ConnectivityManager::isConnected() const
{
    return connected();
}


//==============================================================
// IP Address
//==============================================================

String ConnectivityManager::ipAddress() const
{
    if (!connected())
        return "0.0.0.0";

    return WiFi.localIP().toString();
}


//==============================================================
// MAC Address
//==============================================================

String ConnectivityManager::macAddress() const
{
    return WiFi.macAddress();
}


//==============================================================
// SSID
//==============================================================

String ConnectivityManager::ssid() const
{
    if (!connected())
        return "";

    return WiFi.SSID();
}


//==============================================================
// Signal Strength
//==============================================================

int ConnectivityManager::signalStrength() const
{
    if (!connected())
        return 0;

    return WiFi.RSSI();
}


//==============================================================
// Last Reconnect Time
//==============================================================

unsigned long ConnectivityManager::reconnectTime() const
{
    return _lastReconnect;
}

} // namespace OIF