#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : MQTTManager.h
    Description : MQTT Communication Manager

    Version     : 3.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#ifndef OIF_MQTT_MANAGER_H
#define OIF_MQTT_MANAGER_H

#include "../Platform.h"

#include <WiFiClient.h>
#include <PubSubClient.h>

namespace OIF
{

//==============================================================
// MQTT Message Callback
//==============================================================

typedef void (*MQTTMessageCallback)(
    const char* topic,
    const char* payload
);


//==============================================================
// MQTT Manager
//==============================================================

class MQTTManager
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    MQTTManager();

    //----------------------------------------------------------
    // Framework Lifecycle
    //----------------------------------------------------------

    bool begin();

    void run();

    void stop();

    //----------------------------------------------------------
    // Connection
    //----------------------------------------------------------

    bool connect();

    void disconnect();

    bool reconnect();

    bool connected();

    //----------------------------------------------------------
    // Publish / Subscribe
    //----------------------------------------------------------

    bool publish(
        const char* topic,
        const char* payload,
        bool retained = false
    );

    bool subscribe(
        const char* topic
    );

    bool unsubscribe(
        const char* topic
    );

    //----------------------------------------------------------
    // Configuration
    //----------------------------------------------------------

    void setServer(
        const char* host,
        uint16_t port
    );

    void setCredentials(
        const char* username,
        const char* password
    );

    void setClientID(
        const char* id
    );

    void setKeepAlive(
        uint16_t seconds
    );

    //----------------------------------------------------------
    // Callback
    //----------------------------------------------------------

    void onMessage(
        MQTTMessageCallback callback
    );

    //----------------------------------------------------------
    // Information
    //----------------------------------------------------------

    const char* host() const;

    uint16_t port() const;

    const char* clientID() const;

private:

    //----------------------------------------------------------
    // MQTT Client
    //----------------------------------------------------------

    WiFiClient _wifiClient;

    PubSubClient _client;

    //----------------------------------------------------------
    // Configuration
    //----------------------------------------------------------

    char _host[64];

    uint16_t _port;

    char _username[32];

    char _password[32];

    char _clientID[32];

    uint16_t _keepAlive;

    //----------------------------------------------------------
    // Runtime
    //----------------------------------------------------------

    bool _enabled;

    bool _waitingForWiFi;

    unsigned long _lastReconnect;

    MQTTMessageCallback _callback;

    //----------------------------------------------------------
    // Static Callback Bridge
    //----------------------------------------------------------

    static MQTTManager* _instance;

    static void mqttCallback(
        char* topic,
        byte* payload,
        unsigned int length
    );
};


//==============================================================
// Global Instance
//==============================================================

extern MQTTManager MQTT;

} // namespace OIF

#endif // OIF_MQTT_MANAGER_H