#pragma once

#ifndef CONFIG_MANAGER_H
#define CONFIG_MANAGER_H

/*****************************************************************
    OpenIoT Framework

    File        : ConfigManager.h
    Description : Central Configuration Manager

    Version     : 1.1.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "../Platform.h"

namespace OIF
{

//==============================================================
// Device Configuration
//==============================================================

struct DeviceConfig
{
    char name[32];
    char version[16];
};


//==============================================================
// Network Configuration
//==============================================================

struct NetworkConfig
{
    char ssid[32];
    char password[64];
    char hostname[32];
};


//==============================================================
// Web Configuration
//==============================================================

struct WebConfig
{
    uint16_t port;
};


//==============================================================
// MQTT Configuration
//==============================================================

struct MQTTConfig
{
    bool enabled;

    char host[64];

    uint16_t port;

    char clientId[32];

    char username[32];

    char password[64];

    char baseTopic[64];
};


//==============================================================
// GitHub OTA Configuration
//==============================================================

struct GitHubConfig
{
    char owner[64];

    char repository[64];

    char branch[32];

    char channel[16];
};


//==============================================================
// Configuration Manager
//==============================================================

class ConfigManager
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    ConfigManager();

    //----------------------------------------------------------
    // Initialization
    //----------------------------------------------------------

    bool begin();

    //----------------------------------------------------------
    // Reset Configuration
    //----------------------------------------------------------

    void reset();

    //----------------------------------------------------------
    // Configuration Access
    //----------------------------------------------------------

    const DeviceConfig& device() const;

    const NetworkConfig& network() const;

    const WebConfig& web() const;

    const MQTTConfig& mqtt() const;

    const GitHubConfig& github() const;

private:

    //----------------------------------------------------------
    // Load Default Configuration
    //----------------------------------------------------------

    void loadDefaults();

    //----------------------------------------------------------
    // Internal Configuration Storage
    //----------------------------------------------------------

    DeviceConfig  _device;

    NetworkConfig _network;

    WebConfig     _web;

    MQTTConfig    _mqtt;

    GitHubConfig  _github;
};


//==============================================================
// Global Configuration Instance
//==============================================================

extern ConfigManager Config;

} // namespace OIF

#endif // CONFIG_MANAGER_H