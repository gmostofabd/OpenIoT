/*****************************************************************
    OpenIoT Framework

    File        : MQTTManager.cpp
    Description : MQTT Communication Manager

    Version     : 3.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "MQTTManager.h"

#include "ConnectivityManager.h"
#include "ConfigManager.h"
#include "LoggerManager.h"

#include <string.h>

namespace OIF
{

//==============================================================
// Global Instance
//==============================================================

MQTTManager MQTT;


//==============================================================
// Static Instance
//==============================================================

MQTTManager* MQTTManager::_instance = nullptr;


//==============================================================
// Constructor
//==============================================================

MQTTManager::MQTTManager()
    : _client(_wifiClient)
{
    _instance = this;

    _enabled = false;
    _waitingForWiFi = true;
    _lastReconnect = 0;

    _callback = nullptr;

    memset(_host, 0, sizeof(_host));
    memset(_username, 0, sizeof(_username));
    memset(_password, 0, sizeof(_password));
    memset(_clientID, 0, sizeof(_clientID));

    _port = 1883;
    _keepAlive = 15;
}


//==============================================================
// Initialize
//==============================================================

bool MQTTManager::begin()
{
    const MQTTConfig& cfg = Config.mqtt();

    setServer(
        cfg.host,
        cfg.port
    );

    setCredentials(
        cfg.username,
        cfg.password
    );

    setClientID(
        cfg.clientId
    );

    setKeepAlive(15);

    _client.setServer(
        _host,
        _port
    );

    _client.setKeepAlive(
        _keepAlive
    );

    _client.setCallback(
        mqttCallback
    );

    _enabled = cfg.enabled;

    Log.info(
        "MQTT",
        "MQTT Manager Ready"
    );

    return true;
}


//==============================================================
// Main Loop
//==============================================================

void MQTTManager::run()
{
    if (!_enabled)
        return;

    if (!Connectivity.connected())
    {
        _waitingForWiFi = true;
        return;
    }

    if (_waitingForWiFi)
    {
        _waitingForWiFi = false;

        _client.setServer(
            _host,
            _port
        );
    }

    if (!_client.connected())
    {
        if (millis() - _lastReconnect >= 5000)
        {
            _lastReconnect = millis();
            connect();
        }

        return;
    }

    _client.loop();
}


//==============================================================
// Stop
//==============================================================

void MQTTManager::stop()
{
    _enabled = false;

    if (_client.connected())
    {
        _client.disconnect();
    }

    Log.info(
        "MQTT",
        "Stopped"
    );
}


//==============================================================
// Connect
//==============================================================

bool MQTTManager::connect()
{
    Log.info(
        "MQTT",
        "Connecting..."
    );

    bool ok;

    if (strlen(_username))
    {
        ok = _client.connect(
            _clientID,
            _username,
            _password
        );
    }
    else
    {
        ok = _client.connect(
            _clientID
        );
    }

    if (ok)
    {
        Log.success(
            "MQTT",
            "Connected"
        );

        return true;
    }

    Log.warning(
        "MQTT",
        "Failed (%d)",
        _client.state()
    );

    return false;
}


//==============================================================
// Disconnect
//==============================================================

void MQTTManager::disconnect()
{
    _client.disconnect();
}


//==============================================================
// Reconnect
//==============================================================

bool MQTTManager::reconnect()
{
    disconnect();
    return connect();
}


//==============================================================
// Connected
//==============================================================

bool MQTTManager::connected()
{
    return _client.connected();
}


//==============================================================
// Publish
//==============================================================

bool MQTTManager::publish(
    const char* topic,
    const char* payload,
    bool retained
)
{
    if (!_client.connected())
        return false;

    return _client.publish(
        topic,
        payload,
        retained
    );
}


//==============================================================
// Subscribe
//==============================================================

bool MQTTManager::subscribe(
    const char* topic
)
{
    if (!_client.connected())
        return false;

    return _client.subscribe(topic);
}


//==============================================================
// Unsubscribe
//==============================================================

bool MQTTManager::unsubscribe(
    const char* topic
)
{
    if (!_client.connected())
        return false;

    return _client.unsubscribe(topic);
}


//==============================================================
// Configuration
//==============================================================

void MQTTManager::setServer(
    const char* host,
    uint16_t port
)
{
    if (host == nullptr)
        return;

    strncpy(
        _host,
        host,
        sizeof(_host) - 1
    );

    _host[sizeof(_host) - 1] = '\0';

    _port = port;

    _client.setServer(
        _host,
        _port
    );
}

void MQTTManager::setCredentials(
    const char* username,
    const char* password
)
{
    if (username)
    {
        strncpy(
            _username,
            username,
            sizeof(_username) - 1
        );

        _username[sizeof(_username) - 1] = '\0';
    }

    if (password)
    {
        strncpy(
            _password,
            password,
            sizeof(_password) - 1
        );

        _password[sizeof(_password) - 1] = '\0';
    }
}

void MQTTManager::setClientID(
    const char* id
)
{
    if (id == nullptr)
        return;

    strncpy(
        _clientID,
        id,
        sizeof(_clientID) - 1
    );

    _clientID[sizeof(_clientID) - 1] = '\0';
}

void MQTTManager::setKeepAlive(
    uint16_t seconds
)
{
    _keepAlive = seconds;

    _client.setKeepAlive(
        seconds
    );
}


//==============================================================
// Message Callback
//==============================================================

void MQTTManager::onMessage(
    MQTTMessageCallback callback
)
{
    _callback = callback;
}


//==============================================================
// Static Callback
//==============================================================

void MQTTManager::mqttCallback(
    char* topic,
    byte* payload,
    unsigned int length
)
{
    if (_instance == nullptr)
        return;

    String message;

    message.reserve(length + 1);

    for (unsigned int i = 0; i < length; i++)
    {
        message += (char)payload[i];
    }

    Log.info(
        "MQTT",
        "RX [%s] %s",
        topic,
        message.c_str()
    );

    if (_instance->_callback)
    {
        _instance->_callback(
            topic,
            message.c_str()
        );
    }
}


//==============================================================
// Information
//==============================================================

const char* MQTTManager::host() const
{
    return _host;
}

uint16_t MQTTManager::port() const
{
    return _port;
}

const char* MQTTManager::clientID() const
{
    return _clientID;
}

} // namespace OIF