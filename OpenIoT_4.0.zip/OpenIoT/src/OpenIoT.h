#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : OpenIoT.h
    Description : Main Framework Interface

    Version     : 2.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "Platform.h"

//==============================================================
// Core Managers
//==============================================================

#include "managers/LoggerManager.h"
#include "managers/ConfigManager.h"
#include "managers/VersionManager.h"
#include "managers/FileManager.h"

#include "managers/ConnectivityManager.h"

#include "managers/WebManager.h"
#include "managers/DashboardManager.h"

#include "managers/JSONManager.h"

#include "managers/OTAManager.h"
//#include "managers/GitHubOTAManager.h"

//#include "managers/MQTTManager.h"
//#include "managers/FirebaseManager.h"

//==============================================================
// Framework Namespace
//==============================================================

namespace OIF
{

//==============================================================
// Framework Information
//==============================================================

constexpr const char*
FRAMEWORK_NAME =
    "OpenIoT";

constexpr const char*
FRAMEWORK_VERSION =
    "2.0.0";


//==============================================================
// OpenIoT Framework
//==============================================================

class OpenIoT
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    OpenIoT();

    //----------------------------------------------------------
    // Framework Life Cycle
    //----------------------------------------------------------

    bool begin();

    void run();

    inline void loop()
    {
        run();
    }

    void stop();

    void restart();

    //----------------------------------------------------------
    // Status
    //----------------------------------------------------------

    bool initialized() const;

    bool started() const;

    //----------------------------------------------------------
    // Information
    //----------------------------------------------------------

    const char* version() const;

    const char* name() const;

private:

    //----------------------------------------------------------
    // Internal State
    //----------------------------------------------------------

    bool _initialized;
};


//==============================================================
// Global Framework Instance
//==============================================================

extern OpenIoT Framework;

}   // namespace OIF