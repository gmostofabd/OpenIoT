#pragma once

/*****************************************************************
    OpenIoT Framework (OIF)

    File        : OIF_Kernel.h
    Description : Framework Kernel

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "../Platform.h"

#include "../managers/ServiceManager.h"

namespace OIF
{

//==============================================================
// FRAMEWORK KERNEL
//==============================================================

class Kernel
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    Kernel();

    //----------------------------------------------------------
    // Framework Life Cycle
    //----------------------------------------------------------

    Result begin();

    Result run();

    Result stop();

    //----------------------------------------------------------
    // Service Management
    //----------------------------------------------------------

    Result addService(
        Service* service
    );

    Result removeService(
        Service* service
    );

    Service* service(
        ServiceId id
    );

    //----------------------------------------------------------
    // Information
    //----------------------------------------------------------

    uint8_t serviceCount() const;

private:

    ServiceRegistry _registry;

};


//==============================================================
// GLOBAL KERNEL
//==============================================================

extern Kernel OIF;

} // namespace OIF