/*****************************************************************
    OpenIoT Framework (OIF)

    File        : OIF_Config.h
    Version     : 0.1.0

    Description :
    Global framework configuration.

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#ifndef OIF_CONFIG_H
#define OIF_CONFIG_H

#include <Arduino.h>

namespace oif
{
    namespace config
    {
        //========================================================
        // Framework
        //========================================================

        constexpr uint8_t MAX_SERVICES        = 16;
        constexpr uint8_t MAX_DEVICES         = 32;
        constexpr uint8_t MAX_DRIVERS         = 32;

        //========================================================
        // Communication
        //========================================================

        constexpr uint16_t MAX_PACKET_SIZE    = 512;
        constexpr uint16_t UART_RX_BUFFER     = 256;
        constexpr uint16_t UART_TX_BUFFER     = 256;

        //========================================================
        // Logger
        //========================================================

        constexpr uint16_t LOG_BUFFER_SIZE    = 256;

        //========================================================
        // Dashboard
        //========================================================

        constexpr uint8_t MAX_CLIENTS         = 5;

        //========================================================
        // Timing
        //========================================================

        constexpr uint32_t DEFAULT_UPDATE_MS  = 10;
        constexpr uint32_t WATCHDOG_TIMEOUT   = 5000;

    }   // namespace config

}   // namespace oif

#endif