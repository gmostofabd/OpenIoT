#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : ServiceManager.h
    Description : Base Service Manager

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "../Platform.h"

namespace OIF
{

//==============================================================
// Result Codes
//==============================================================

enum class Result : uint8_t
{
    OK = 0,
    ERROR,
    INVALID_PARAMETER,
    NOT_FOUND,
    NOT_SUPPORTED,
    TIMEOUT,
    BUSY
};


//==============================================================
// Service IDs
//==============================================================

enum class ServiceId : uint8_t
{
    UNKNOWN = 0,

    LOGGER,
    VERSION,
    CONFIG,
    FILESYSTEM,

    CONNECTIVITY,
    WEB,
    DASHBOARD,
    JSON,

    OTA,
    GITHUB_OTA,

    MQTT,
    FIREBASE,

    SENSOR
};


//==============================================================
// Base Service
//==============================================================

class Service
{
public:

    Service(
        ServiceId id,
        const char* name
    );

    virtual ~Service() {}

    //----------------------------------------------------------
    // Life Cycle
    //----------------------------------------------------------

    virtual Result begin()
    {
        return Result::OK;
    }

    virtual Result run()
    {
        return Result::OK;
    }

    virtual Result stop()
    {
        return Result::OK;
    }

    //----------------------------------------------------------
    // Information
    //----------------------------------------------------------

    ServiceId id() const
    {
        return _id;
    }

    const char* name() const
    {
        return _name;
    }

    //----------------------------------------------------------
    // Enable / Disable
    //----------------------------------------------------------

    void enable(bool state = true)
    {
        _enabled = state;
    }

    bool enabled() const
    {
        return _enabled;
    }

protected:

    ServiceId _id;

    const char* _name;

    bool _enabled;
};


//==============================================================
// Service Registry
//==============================================================

class ServiceRegistry
{
public:

    static const uint8_t MAX_SERVICES = 32;

    ServiceRegistry();

    Result add(
        Service* service
    );

    Result remove(
        Service* service
    );

    Service* find(
        ServiceId id
    ) const;

    Service* get(
        uint8_t index
    ) const;

    uint8_t count() const;

private:

    Service* _services[MAX_SERVICES];

    uint8_t _count;
};

} // namespace OIF