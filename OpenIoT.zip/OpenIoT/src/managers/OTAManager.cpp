/*****************************************************************
    OpenIoT Framework

    File        : OTAManager.cpp
    Description : Arduino OTA Manager

    Version     : 2.0.0

    License     : MIT
*****************************************************************/

#include "OTAManager.h"

#include "LoggerManager.h"
#include "VersionManager.h"

#if defined(ESP32) || defined(ESP8266)
#include <ArduinoOTA.h>
#endif

namespace OIF
{

OTAManager OTA;

/*********************************************************
    Constructor
*********************************************************/

OTAManager::OTAManager()
{
    _enabled = false;
}


/*********************************************************
    Initialize OTA
*********************************************************/

bool OTAManager::begin()
{

#if defined(ESP32) || defined(ESP8266)

    if (_enabled)
        return true;

    ArduinoOTA.setHostname(
        Version.name()
    );

    //-----------------------------------------------------
    // OTA Start
    //-----------------------------------------------------

    ArduinoOTA.onStart(
        []()
        {
            Log.info(
                "OTA",
                "Update Started"
            );
        }
    );

    //-----------------------------------------------------
    // OTA End
    //-----------------------------------------------------

    ArduinoOTA.onEnd(
        []()
        {
            Log.info(
                "OTA",
                "Update Completed"
            );
        }
    );

    //-----------------------------------------------------
    // OTA Progress
    //-----------------------------------------------------

    ArduinoOTA.onProgress(
        [](unsigned int progress,
           unsigned int total)
        {
            uint8_t percent =
                (progress * 100U) / total;

            Log.info(
                "OTA",
                "Progress : %u%%",
                percent
            );
        }
    );

    //-----------------------------------------------------
    // OTA Error
    //-----------------------------------------------------

    ArduinoOTA.onError(
        [](ota_error_t error)
        {
            switch (error)
            {
                case OTA_AUTH_ERROR:
                    Log.error(
                        "OTA",
                        "Authentication Failed"
                    );
                    break;

                case OTA_BEGIN_ERROR:
                    Log.error(
                        "OTA",
                        "Begin Failed"
                    );
                    break;

                case OTA_CONNECT_ERROR:
                    Log.error(
                        "OTA",
                        "Connection Failed"
                    );
                    break;

                case OTA_RECEIVE_ERROR:
                    Log.error(
                        "OTA",
                        "Receive Failed"
                    );
                    break;

                case OTA_END_ERROR:
                    Log.error(
                        "OTA",
                        "End Failed"
                    );
                    break;

                default:
                    Log.error(
                        "OTA",
                        "Unknown Error"
                    );
                    break;
            }
        }
    );

    ArduinoOTA.begin();

    _enabled = true;

    Log.info(
        "OTA",
        "Arduino OTA Ready"
    );

#else

    Log.warning(
        "OTA",
        "Platform Not Supported"
    );

#endif

    return _enabled;
}


/*********************************************************
    OTA Task
*********************************************************/

void OTAManager::run()
{

#if defined(ESP32) || defined(ESP8266)

    if (!_enabled)
        return;

    ArduinoOTA.handle();

#endif

}


/*********************************************************
    Stop OTA
*********************************************************/

void OTAManager::stop()
{
    _enabled = false;

    Log.info(
        "OTA",
        "OTA Disabled"
    );
}


/*********************************************************
    Status
*********************************************************/

bool OTAManager::enabled() const
{
    return _enabled;
}

} // namespace OIF