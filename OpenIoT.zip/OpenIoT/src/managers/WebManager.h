#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : WebManager.h
    Description : Embedded Web Server Manager

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "../Platform.h"

namespace OIF
{

//==============================================================
// Web Manager
//==============================================================

class WebManager
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    WebManager();

    //----------------------------------------------------------
    // Initialization
    //----------------------------------------------------------

    bool begin();

    //----------------------------------------------------------
    // Main Loop
    //----------------------------------------------------------

    void run();

    //----------------------------------------------------------
    // Stop Server
    //----------------------------------------------------------

    void stop();

private:

#if defined(ESP32)

    WebServer _server;

#elif defined(ESP8266)

    ESP8266WebServer _server;

#endif

    bool _running;

    //----------------------------------------------------------
    // Route Registration
    //----------------------------------------------------------

    void registerRoutes();

    //----------------------------------------------------------
    // Response Helper
    //----------------------------------------------------------

    void sendJSON(
        const String& json,
        int code = 200
    );

    //----------------------------------------------------------
    // Route Handlers
    //----------------------------------------------------------

    void handleRoot();

    void handleSystem();

    void handleDevice();

    void handleNetwork();

    void handleHealth();

    void handleVersion();

    void handle404();

};


//==============================================================
// Global Instance
//==============================================================

extern WebManager Web;

} // namespace OIF