#pragma once

/*****************************************************************
    OpenIoT Framework

    File        : OpenIoT.h
    Description : Main Framework Interface

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "Platform.h"

//--------------------------------------------------------------
// Public Managers
//--------------------------------------------------------------

#include "managers/LoggerManager.h"
#include "managers/VersionManager.h"
#include "managers/OTAManager.h"
#include "managers/WebManager.h"
#include "managers/DashboardManager.h"

namespace OIF
{

//==============================================================
// OpenIoT Framework
//==============================================================

class OpenIoT
{
public:

    //----------------------------------------------------------
    // Constructor
    //----------------------------------------------------------

    OpenIoT();

    //----------------------------------------------------------
    // Framework Life Cycle
    //----------------------------------------------------------

    bool begin();

    void run();

    void stop();

    //----------------------------------------------------------
    // Status
    //----------------------------------------------------------

    bool initialized() const;

    //----------------------------------------------------------
    // Version
    //----------------------------------------------------------

    const char* version() const;

    const char* name() const;

private:

    bool _initialized;
};


//==============================================================
// Global Framework Instance
//==============================================================

extern OpenIoT Framework;

} // namespace OIF