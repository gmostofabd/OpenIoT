/*****************************************************************
    OpenIoT Framework

    File        : OpenIoT.cpp
    Description : Main Framework Class

    Version     : 1.0.0

    License     : MIT

    Developed By:
    Md. Golam Mostofa
*****************************************************************/

#include "OpenIoT.h"

#include "managers/LoggerManager.h"
#include "managers/VersionManager.h"
#include "managers/DashboardManager.h"
#include "managers/WebManager.h"
#include "managers/OTAManager.h"

namespace OIF
{

//==============================================================
// Global Framework Instance
//==============================================================

OpenIoT Framework;


//==============================================================
// Constructor
//==============================================================

OpenIoT::OpenIoT()
{
    _initialized = false;
}


//==============================================================
// Initialize Framework
//==============================================================

bool OpenIoT::begin()
{
    if (_initialized)
        return true;

    //----------------------------------------------------------
    // Logger
    //----------------------------------------------------------

    Log.begin();

    //----------------------------------------------------------
    // Version
    //----------------------------------------------------------

    Version.begin();

    //----------------------------------------------------------
    // Dashboard
    //----------------------------------------------------------

    Dashboard.begin();

    //----------------------------------------------------------
    // Web Server
    //----------------------------------------------------------

    Web.begin();

    //----------------------------------------------------------
    // OTA
    //----------------------------------------------------------

    OTA.begin();

    _initialized = true;

    Log.success(
        "OIF",
        "Framework Initialized"
    );

    return true;
}


//==============================================================
// Framework Task
//==============================================================

void OpenIoT::run()
{
    if (!_initialized)
        return;

    OTA.run();

    Web.run();

    Dashboard.run();

    Log.run();
}


//==============================================================
// Shutdown
//==============================================================

void OpenIoT::stop()
{
    if (!_initialized)
        return;

    OTA.stop();

    Web.stop();

    Dashboard.stop();

    Log.stop();

    _initialized = false;

    Log.info(
        "OIF",
        "Framework Stopped"
    );
}

} // namespace OIF